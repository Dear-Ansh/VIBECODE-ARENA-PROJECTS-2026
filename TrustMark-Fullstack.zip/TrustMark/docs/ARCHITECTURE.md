# Architecture

## Data model
`brands` → `products` (gtin, category, referenceImages, expectedKeywords) → `batches` (batchCode, status: active/expired/recalled)
→ `identifiers` (token TM-XX-0000-XXXX, status active/revoked, singleUse).
`scans` record each check (token, city, deviceId, verdict, score). `alerts` are raised from scans. `reports` are consumer submissions. `auditLog` records admin changes.

## API
| Method | Path | Access | Purpose |
|---|---|---|---|
| POST | /api/verify | public | multipart: identifier, batch, city, deviceId, labelText, image |
| GET | /api/verify/warnings/:token | public | previous alerts for a code |
| GET | /api/verify/history?deviceId= | public | checks from one device |
| POST | /api/reports | public | multipart report with up to 4 images |
| GET | /api/reports/track/:id | public | report status |
| POST | /api/auth/login | public | returns JWT |
| GET | /api/admin/stats, /registry, /reports, /alerts | admin | dashboard data |
| POST/PUT/PATCH | /api/admin/brands, products, batches, identifiers | admin | manage registry |
| POST | /api/admin/products/:id/images | admin | add reference images |
| PATCH | /api/admin/reports/:id, /alerts/:id | admin | review workflow |

## Risk rules (server/src/services/riskEngine.js)
Score = sum of signal points, clamped 0-100. Under 25 Likely Genuine, 25-54 Needs Further Verification, 55+ Potentially Counterfeit.
A revoked code is always Potentially Counterfeit. A recalled batch is never lower than Needs Further Verification and shows a safety notice.
A barcode (GTIN) alone never reaches Likely Genuine because barcodes are identical on every unit.

| Signal | Points |
|---|---|
| Invalid format / unknown barcode | 40 |
| Unknown code | 45 |
| Revoked code | 100 (override) |
| Recalled batch | 40 (override: at least verify) |
| Expired batch | 30 |
| Batch mismatch | 35 |
| Single-use code reused from another device | 35 |
| Scan burst (4+ devices in 24 h) | 30 |
| Many devices / many cities | 20 / 15 |
| Impossible travel (over 900 km/h) | 40 |
| Earlier open warnings | 10 |
| Packaging layout differs (dHash 22+/64, partial 12+) | 35 / 20 |
| Colour mismatch | 10 |
| Spelling differs from official text | 25 each, max 40 |
| Missing expected text | 10 each, max 20 |
| Registered and consistent | -15 |
| Packaging matches reference | -10 |

Thresholds live in `server/src/config/index.js`.
