import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import { fmtDate, getDeviceId } from '../utils/device.js';
import { VerdictPill, StatusPill } from '../components/Badges.jsx';

export default function History() {
  const [scans, setScans] = useState(null);
  const [lookup, setLookup] = useState('');
  const [warn, setWarn] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { api.history(getDeviceId()).then((d) => setScans(d.scans)).catch((e) => setError(e.message)); }, []);

  const search = async (e) => {
    e.preventDefault(); setError('');
    try { setWarn(await api.warnings(lookup.trim())); } catch (err) { setError(err.message); }
  };

  return (
    <div className="narrow stack-lg">
      <div><h2>My checks</h2><p className="muted">Checks made on this device. History is linked to this browser, not to an account.</p></div>
      {error && <div className="alert bad">{error}</div>}

      <section className="card stack">
        <h3>Look up warnings for a code</h3>
        <form className="row" onSubmit={search}>
          <input style={{ flex: '1 1 240px' }} className="mono" aria-label="Code" placeholder="TM-CW-0042-XK77" value={lookup} onChange={(e) => setLookup(e.target.value)} />
          <button className="btn secondary">Look up</button>
        </form>
        {warn && (
          <div className="stack">
            <p className="small muted"><strong>{warn.token}</strong>: {warn.totalScans} checks, {warn.flaggedScans} flagged, {warn.reportCount} report(s).</p>
            {warn.alerts.length === 0 ? <div className="alert ok">No warnings recorded for this code.</div> :
              <div className="table-wrap"><table><thead><tr><th>When</th><th>Warning</th><th>Status</th></tr></thead><tbody>
                {warn.alerts.map((a) => <tr key={a.id}><td>{fmtDate(a.createdAt)}</td><td>{a.summary}</td><td><StatusPill value={a.status} /></td></tr>)}
              </tbody></table></div>}
          </div>
        )}
      </section>

      <section className="stack">
        <h3>Recent checks</h3>
        {scans === null ? <p className="muted">Loading</p> : scans.length === 0 ?
          <div className="card"><p className="muted">You have not checked anything yet.</p><Link className="btn" style={{ marginTop: '.75rem' }} to="/verify">Check a product</Link></div> :
          <div className="table-wrap"><table><thead><tr><th>When</th><th>Code</th><th>Product</th><th>Result</th><th>Score</th></tr></thead><tbody>
            {scans.map((s) => (
              <tr key={s.id}><td>{fmtDate(s.at)}</td><td className="mono">{s.token}</td><td>{s.productName || 'Not registered'}</td><td><VerdictPill band={s.verdict} /></td><td>{s.score}</td></tr>
            ))}
          </tbody></table></div>}
      </section>
    </div>
  );
}
