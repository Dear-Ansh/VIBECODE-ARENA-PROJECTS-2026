import { NavLink, Outlet } from 'react-router-dom';
import { LayoutDashboard, Boxes, FileWarning, Siren, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.jsx';

export default function AdminLayout() {
  const { user, logout } = useAuth();
  return (
    <div className="container admin-shell">
      <aside className="side" aria-label="Admin">
        <NavLink end to="/admin"><LayoutDashboard size={18} /> Overview</NavLink>
        <NavLink to="/admin/alerts"><Siren size={18} /> Alerts</NavLink>
        <NavLink to="/admin/reports"><FileWarning size={18} /> Reports</NavLink>
        <NavLink to="/admin/registry"><Boxes size={18} /> Registry</NavLink>
        <div className="small muted" style={{ padding: '.6rem .8rem' }}>{user?.name}</div>
        <a href="#out" onClick={(e) => { e.preventDefault(); logout(); }}><LogOut size={18} /> Sign out</a>
      </aside>
      <section className="stack-lg" style={{ minWidth: 0 }}><Outlet /></section>
    </div>
  );
}
