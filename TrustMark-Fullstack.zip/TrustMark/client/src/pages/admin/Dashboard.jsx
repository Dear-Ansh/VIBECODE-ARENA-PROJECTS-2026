import { useEffect, useState } from 'react';
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell, Pie, PieChart } from 'recharts';
import { api } from '../../api/client.js';
import { fmtDate } from '../../utils/device.js';
import { VerdictPill } from '../../components/Badges.jsx';

const COLORS = { 'Likely Genuine': '#1b7f4b', 'Needs Further Verification': '#d99a1d', 'Potentially Counterfeit': '#b42318' };

export default function Dashboard() {
  const [s, setS] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => { api.admin.stats().then(setS).catch((e) => setError(e.message)); }, []);
  if (error) return <div className="alert bad">{error}</div>;
  if (!s) return <p className="muted">Loading</p>;

  const stats = [['Checks made', s.totals.scans], ['Open alerts', s.totals.openAlerts], ['New reports', s.totals.newReports], ['Registered products', s.totals.products]];
  return (
    <>
      <h2>Overview</h2>
      <div className="grid cols-3">{stats.map(([l, v]) => <div className="card stat" key={l}><b>{v}</b><span className="muted small">{l}</span></div>)}</div>

      <div className="grid cols-2">
        <div className="card"><h3>Checks in the last 7 days</h3>
          <div style={{ height: 240, marginTop: '1rem' }}><ResponsiveContainer><BarChart data={s.perDay}><CartesianGrid strokeDasharray="3 3" vertical={false} /><XAxis dataKey="day" /><YAxis allowDecimals={false} /><Tooltip /><Legend />
            <Bar dataKey="scans" name="All checks" fill="#0b7a75" radius={[4, 4, 0, 0]} /><Bar dataKey="flagged" name="Flagged" fill="#b42318" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div></div>
        <div className="card"><h3>Results by rating</h3>
          <div style={{ height: 240, marginTop: '1rem' }}><ResponsiveContainer><PieChart><Pie data={s.byVerdict} dataKey="count" nameKey="band" innerRadius={50} outerRadius={85}>{s.byVerdict.map((d) => <Cell key={d.band} fill={COLORS[d.band]} />)}</Pie><Tooltip /><Legend /></PieChart></ResponsiveContainer></div></div>
      </div>

      <div className="grid cols-2">
        <div className="card stack"><h3>Most checked codes</h3>
          {s.topCodes.map((c) => <div className="row between" key={c.token}><span className="mono">{c.token}</span><span className="pill neutral">{c.count} checks</span></div>)}</div>
        <div className="card stack"><h3>Recent admin activity</h3>
          {s.audit.length === 0 ? <p className="muted small">No changes yet.</p> : s.audit.map((a) => <div key={a.id} className="small"><strong>{a.by}</strong> {a.action} <span className="mono">{a.target}</span> <span className="muted">{fmtDate(a.at)}</span></div>)}</div>
      </div>

      <div className="stack"><h3>Latest checks</h3>
        <div className="table-wrap"><table><thead><tr><th>When</th><th>Code</th><th>City</th><th>Result</th></tr></thead><tbody>
          {s.recentScans.map((x) => <tr key={x.id}><td>{fmtDate(x.at)}</td><td className="mono">{x.token}</td><td>{x.city}</td><td><VerdictPill band={x.verdict} /></td></tr>)}
        </tbody></table></div></div>
    </>
  );
}
