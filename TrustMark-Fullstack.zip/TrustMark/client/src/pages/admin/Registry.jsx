import { useEffect, useState } from 'react';
import { api } from '../../api/client.js';
import { StatusPill } from '../../components/Badges.jsx';

export default function Registry() {
  const [data, setData] = useState(null);
  const [tab, setTab] = useState('products');
  const [msg, setMsg] = useState({ type: '', text: '' });
  const load = () => api.admin.registry().then(setData).catch((e) => setMsg({ type: 'bad', text: e.message }));
  useEffect(() => { load(); }, []);
  const run = async (fn, ok) => {
    try { await fn(); setMsg({ type: 'ok', text: ok }); load(); return true; }
    catch (e) { setMsg({ type: 'bad', text: e.fields ? e.fields.map((f) => f.message).join(' ') : e.message }); return false; }
  };
  if (!data) return <p className="muted">Loading</p>;

  return (
    <>
      <h2>Product registry</h2>
      <div className="tabs" role="tablist">{['products', 'batches', 'codes'].map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}>{t[0].toUpperCase() + t.slice(1)}</button>)}</div>
      {msg.text && <div className={`alert ${msg.type}`} role="status">{msg.text}</div>}
      {tab === 'products' && <Products data={data} run={run} />}
      {tab === 'batches' && <Batches data={data} run={run} />}
      {tab === 'codes' && <Codes data={data} run={run} />}
    </>
  );
}

function Products({ data, run }) {
  const empty = { brandId: data.brands[0]?.id || '', name: '', category: 'cosmetics', gtin: '', keywords: '' };
  const [f, setF] = useState(empty);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const brandName = (id) => data.brands.find((b) => b.id === id)?.name;
  const [newBrand, setNewBrand] = useState('');

  return (
    <>
      <form className="card stack" onSubmit={async (e) => { e.preventDefault(); if (await run(() => api.admin.createProduct({ brandId: f.brandId, name: f.name, category: f.category, gtin: f.gtin, expectedKeywords: f.keywords.split(',').map((x) => x.trim()).filter(Boolean) }), 'Product added.')) setF(empty); }}>
        <h3>Add product</h3>
        <div className="grid cols-2">
          <div className="field"><label>Brand</label><select value={f.brandId} onChange={set('brandId')}>{data.brands.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select></div>
          <div className="field"><label>Category</label><select value={f.category} onChange={set('category')}>{['cosmetics', 'medicine', 'electronics', 'clothing', 'food', 'other'].map((c) => <option key={c}>{c}</option>)}</select></div>
          <div className="field"><label>Product name</label><input value={f.name} onChange={set('name')} required /></div>
          <div className="field"><label>Barcode (GTIN)</label><input className="mono" value={f.gtin} onChange={set('gtin')} placeholder="8901234567890" required /></div>
        </div>
        <div className="field"><label>Words that must appear on the label <span className="hint">(comma separated)</span></label><input value={f.keywords} onChange={set('keywords')} placeholder="GlowSkin, Vitamin C, Serum" /></div>
        <div className="row"><button className="btn">Add product</button></div>
      </form>
      <form className="card row" onSubmit={async (e) => { e.preventDefault(); if (await run(() => api.admin.createBrand({ name: newBrand }), 'Brand added.')) setNewBrand(''); }}>
        <input style={{ flex: '1 1 220px' }} aria-label="New brand name" placeholder="New brand name" value={newBrand} onChange={(e) => setNewBrand(e.target.value)} required /><button className="btn secondary">Add brand</button>
      </form>
      <div className="table-wrap"><table><thead><tr><th>Product</th><th>Brand</th><th>Barcode</th><th>Reference images</th></tr></thead><tbody>
        {data.products.map((p) => (
          <tr key={p.id}><td><strong>{p.name}</strong><div className="small muted">{p.category}</div></td><td>{brandName(p.brandId)}</td><td className="mono">{p.gtin}</td>
            <td><div className="thumbs" style={{ marginTop: 0 }}>{p.referenceImages.map((i) => <img key={i} src={`/uploads/reference/${i}`} alt="Reference" style={{ width: 44, height: 44 }} />)}</div>
              <label className="btn secondary small" style={{ marginTop: '.4rem', marginBottom: 0 }}>Add image
                <input type="file" accept="image/*" hidden onChange={(e) => e.target.files[0] && run(() => api.admin.uploadReference(p.id, [e.target.files[0]]), 'Reference image added.')} /></label></td></tr>
        ))}
      </tbody></table></div>
    </>
  );
}

function Batches({ data, run }) {
  const empty = { productId: data.products[0]?.id || '', batchCode: '', manufacturedOn: '', expiresOn: '' };
  const [f, setF] = useState(empty);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const prod = (id) => data.products.find((p) => p.id === id)?.name;
  return (
    <>
      <form className="card stack" onSubmit={async (e) => { e.preventDefault(); if (await run(() => api.admin.createBatch(f), 'Batch added.')) setF(empty); }}>
        <h3>Add batch</h3>
        <div className="grid cols-2">
          <div className="field"><label>Product</label><select value={f.productId} onChange={set('productId')}>{data.products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
          <div className="field"><label>Batch code</label><input className="mono" value={f.batchCode} onChange={set('batchCode')} required /></div>
          <div className="field"><label>Manufactured</label><input type="date" value={f.manufacturedOn} onChange={set('manufacturedOn')} required /></div>
          <div className="field"><label>Expires</label><input type="date" value={f.expiresOn} onChange={set('expiresOn')} required /></div>
        </div>
        <div className="row"><button className="btn">Add batch</button></div>
      </form>
      <div className="table-wrap"><table><thead><tr><th>Batch</th><th>Product</th><th>Expires</th><th>Status</th><th /></tr></thead><tbody>
        {data.batches.map((b) => (
          <tr key={b.id}><td className="mono">{b.batchCode}</td><td>{prod(b.productId)}</td><td>{b.expiresOn}</td><td><StatusPill value={b.status} /></td>
            <td>{b.status === 'recalled'
              ? <button className="btn secondary small" onClick={() => run(() => api.admin.updateBatch(b.id, { status: 'active' }), 'Recall lifted.')}>Lift recall</button>
              : <button className="btn danger small" onClick={() => run(() => api.admin.updateBatch(b.id, { status: 'recalled', recallReason: 'Recalled by administrator' }), 'Batch recalled.')}>Recall</button>}</td></tr>
        ))}
      </tbody></table></div>
    </>
  );
}

function Codes({ data, run }) {
  const empty = { batchId: data.batches[0]?.id || '', token: '', singleUse: false };
  const [f, setF] = useState(empty);
  const batch = (id) => data.batches.find((b) => b.id === id)?.batchCode;
  return (
    <>
      <form className="card stack" onSubmit={async (e) => { e.preventDefault(); if (await run(() => api.admin.createIdentifier(f), 'Code registered.')) setF(empty); }}>
        <h3>Register a code</h3>
        <div className="grid cols-2">
          <div className="field"><label>Batch</label><select value={f.batchId} onChange={(e) => setF({ ...f, batchId: e.target.value })}>{data.batches.map((b) => <option key={b.id} value={b.id}>{b.batchCode}</option>)}</select></div>
          <div className="field"><label>Code</label><input className="mono" value={f.token} onChange={(e) => setF({ ...f, token: e.target.value.toUpperCase() })} placeholder="TM-GS-0010-AB12" required /></div>
        </div>
        <label className="row" style={{ fontWeight: 500 }}><input type="checkbox" style={{ width: 20, minHeight: 20 }} checked={f.singleUse} onChange={(e) => setF({ ...f, singleUse: e.target.checked })} /> Single-use code (such as medicines)</label>
        <div className="row"><button className="btn">Register code</button></div>
      </form>
      <div className="table-wrap"><table><thead><tr><th>Code</th><th>Batch</th><th>Type</th><th>Status</th><th /></tr></thead><tbody>
        {data.identifiers.map((i) => (
          <tr key={i.id}><td className="mono">{i.token}</td><td className="mono">{batch(i.batchId)}</td><td>{i.singleUse ? 'Single use' : 'Reusable'}</td><td><StatusPill value={i.status} /></td>
            <td>{i.status === 'revoked'
              ? <button className="btn secondary small" onClick={() => run(() => api.admin.updateIdentifier(i.id, { status: 'active' }), 'Code restored.')}>Restore</button>
              : <button className="btn danger small" onClick={() => run(() => api.admin.updateIdentifier(i.id, { status: 'revoked', revokedReason: 'Revoked by administrator' }), 'Code revoked.')}>Revoke</button>}</td></tr>
        ))}
      </tbody></table></div>
    </>
  );
}
