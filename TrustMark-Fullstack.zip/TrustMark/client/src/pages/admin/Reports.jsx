import { useEffect, useState } from 'react';
import { api } from '../../api/client.js';
import { fmtDate } from '../../utils/device.js';
import { StatusPill } from '../../components/Badges.jsx';

export default function Reports() {
  const [reports, setReports] = useState(null);
  const [open, setOpen] = useState(null);
  const [note, setNote] = useState('');
  const [filter, setFilter] = useState('all');
  const [error, setError] = useState('');
  const load = () => api.admin.reports().then((d) => { setReports(d.reports); setOpen((o) => o && d.reports.find((r) => r.id === o.id)); }).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  const update = async (patch) => { try { await api.admin.updateReport(open.id, patch); setNote(''); load(); } catch (e) { setError(e.message); } };
  const shown = (reports || []).filter((r) => filter === 'all' || r.status === filter);

  return (
    <>
      <div className="row between"><h2>Consumer reports</h2>
        <select style={{ width: 'auto' }} aria-label="Filter" value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="all">All</option><option value="new">New</option><option value="under_review">Under review</option><option value="confirmed">Confirmed</option><option value="dismissed">Dismissed</option></select></div>
      {error && <div className="alert bad">{error}</div>}
      <div className="table-wrap"><table><thead><tr><th>Received</th><th>Product</th><th>Where bought</th><th>Priority</th><th>Status</th><th /></tr></thead><tbody>
        {shown.map((r) => (
          <tr key={r.id}><td>{fmtDate(r.createdAt)}</td><td><strong>{r.productName}</strong><div className="small muted mono">{r.identifier || 'no code'}</div></td><td>{r.purchaseLocation}</td>
            <td><StatusPill value={r.priority} /></td><td><StatusPill value={r.status} /></td><td><button className="btn secondary small" onClick={() => setOpen(r)}>Review</button></td></tr>
        ))}
      </tbody></table></div>

      {open && (
        <div className="modal-back" role="dialog" aria-modal="true" aria-label="Report details" onClick={(e) => e.target === e.currentTarget && setOpen(null)}>
          <div className="modal stack">
            <div className="row between"><h3>{open.productName}</h3><button className="btn ghost small" onClick={() => setOpen(null)}>Close</button></div>
            <dl className="kv">
              <dt>Reference</dt><dd className="mono">{open.id}</dd><dt>Code</dt><dd className="mono">{open.identifier || 'None given'}</dd>
              <dt>Bought at</dt><dd>{open.purchaseLocation}</dd><dt>Price</dt><dd>{open.price != null ? `${open.price} ${open.currency}` : 'Not given'}</dd>
              <dt>Contact</dt><dd>{open.contact || 'Not given'}</dd>
            </dl>
            <p>{open.description}</p>
            {open.images?.length > 0 && <div className="thumbs">{open.images.map((i) => <a key={i} href={`/uploads/reports/${i}`} target="_blank" rel="noreferrer"><img src={`/uploads/reports/${i}`} alt="Evidence" /></a>)}</div>}
            <div className="grid cols-2">
              <div className="field"><label>Status</label><select value={open.status} onChange={(e) => update({ status: e.target.value })}><option value="new">New</option><option value="under_review">Under review</option><option value="confirmed">Confirmed counterfeit</option><option value="dismissed">Dismissed</option></select></div>
              <div className="field"><label>Priority</label><select value={open.priority} onChange={(e) => update({ priority: e.target.value })}><option>low</option><option>medium</option><option>high</option></select></div>
            </div>
            <div><h3>Notes</h3>{open.notes.length === 0 && <p className="small muted">No notes yet.</p>}{open.notes.map((n, i) => <p key={i} className="small"><strong>{n.by}</strong> <span className="muted">{fmtDate(n.at)}</span><br />{n.text}</p>)}</div>
            <div className="row"><input style={{ flex: '1 1 200px' }} aria-label="Add note" placeholder="Add a note" value={note} onChange={(e) => setNote(e.target.value)} /><button className="btn small" disabled={!note.trim()} onClick={() => update({ note })}>Add note</button></div>
          </div>
        </div>
      )}
    </>
  );
}
