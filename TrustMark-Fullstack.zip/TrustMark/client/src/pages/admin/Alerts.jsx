import { useEffect, useState } from 'react';
import { api } from '../../api/client.js';
import { fmtDate } from '../../utils/device.js';
import { StatusPill } from '../../components/Badges.jsx';

export default function Alerts() {
  const [alerts, setAlerts] = useState(null);
  const [filter, setFilter] = useState('open');
  const [error, setError] = useState('');
  const load = () => api.admin.alerts().then((d) => setAlerts(d.alerts)).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);
  const act = async (id, status) => { try { await api.admin.updateAlert(id, status); load(); } catch (e) { setError(e.message); } };
  const shown = (alerts || []).filter((a) => filter === 'all' || a.status === filter);

  return (
    <>
      <div className="row between"><h2>Alerts</h2>
        <select style={{ width: 'auto' }} aria-label="Filter" value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="open">Open</option><option value="acknowledged">Acknowledged</option><option value="resolved">Resolved</option><option value="all">All</option></select></div>
      <p className="muted small">Alerts are created automatically when a check shows copied-code behaviour, a revoked code, or a recalled batch.</p>
      {error && <div className="alert bad">{error}</div>}
      <div className="table-wrap"><table><thead><tr><th>Raised</th><th>Severity</th><th>Code</th><th>Detail</th><th>Status</th><th /></tr></thead><tbody>
        {shown.length === 0 && <tr><td colSpan="6" className="muted">Nothing to review here.</td></tr>}
        {shown.map((a) => (
          <tr key={a.id}><td>{fmtDate(a.createdAt)}</td><td><StatusPill value={a.severity} /></td><td className="mono">{a.token}</td><td>{a.summary}</td><td><StatusPill value={a.status} /></td>
            <td><div className="row">
              {a.status === 'open' && <button className="btn secondary small" onClick={() => act(a.id, 'acknowledged')}>Acknowledge</button>}
              {a.status !== 'resolved' && <button className="btn small" onClick={() => act(a.id, 'resolved')}>Resolve</button>}
            </div></td></tr>
        ))}
      </tbody></table></div>
    </>
  );
}
