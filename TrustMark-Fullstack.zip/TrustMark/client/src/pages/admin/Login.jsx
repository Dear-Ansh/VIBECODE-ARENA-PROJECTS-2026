import { useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';

export default function Login() {
  const { user, login } = useAuth();
  const nav = useNavigate();
  const loc = useLocation();
  const [email, setEmail] = useState('admin@trustmark.demo');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/admin" replace />;
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setError('');
    try { await login(email, password); nav(loc.state?.from || '/admin', { replace: true }); }
    catch (err) { setError(err.message); setBusy(false); }
  };

  return (
    <div className="narrow" style={{ maxWidth: 440 }}>
      <form className="card stack" onSubmit={submit}>
        <h2>Administrator sign in</h2>
        <div className="field"><label htmlFor="e">Email</label><input id="e" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" /></div>
        <div className="field"><label htmlFor="p">Password</label><input id="p" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></div>
        {error && <div className="alert bad" role="alert">{error}</div>}
        <button className="btn" disabled={busy}>{busy ? 'Signing in' : 'Sign in'}</button>
        <p className="small muted">Demo account: admin@trustmark.demo with the password set in <code>server/.env</code> (default <code>Admin@123</code>).</p>
      </form>
    </div>
  );
}
