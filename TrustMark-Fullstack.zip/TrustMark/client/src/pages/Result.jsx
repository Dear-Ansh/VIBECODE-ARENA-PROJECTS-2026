import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShieldAlert, ShieldCheck, ShieldQuestion, CheckCircle2, MinusCircle } from 'lucide-react';
import { api } from '../api/client.js';
import { BAND_META, fmtDate } from '../utils/device.js';
import RiskGauge from '../components/RiskGauge.jsx';
import SignalList from '../components/SignalList.jsx';
import Disclaimer from '../components/Disclaimer.jsx';
import { StatusPill } from '../components/Badges.jsx';

const ICON = { ok: ShieldCheck, warn: ShieldQuestion, bad: ShieldAlert };

export default function Result() {
  const loc = useLocation();
  const result = loc.state?.result || JSON.parse(sessionStorage.getItem('trustmark.lastResult') || 'null');
  const [warnings, setWarnings] = useState(null);

  useEffect(() => {
    if (result?.inputType === 'token') api.warnings(result.identifier).then(setWarnings).catch(() => {});
  }, [result?.identifier, result?.inputType]);

  if (!result) return <div className="narrow stack"><h2>No result yet</h2><Link className="btn" to="/verify">Check a product</Link></div>;

  const tone = BAND_META[result.band].tone;
  const Icon = ICON[tone];
  const positives = result.signals.filter((s) => s.points <= 0);
  const imageSkipped = result.checks.find((c) => c.key === 'image' && !c.ran);

  return (
    <div className="narrow stack-lg">
      <section className={`verdict ${tone}`} aria-live="polite">
        <div className="row"><Icon size={34} /><div><div className="small muted">Result for <span className="mono">{result.identifier}</span></div><h1>{result.band}</h1></div></div>
        {result.safetyAlert && <div className="alert bad"><strong>Safety notice.</strong> This product belongs to a recalled batch. Stop using it and contact the brand.</div>}
        <RiskGauge score={result.score} />
        <p className="small muted">Risk score {result.score} out of 100. It is a rule-based indicator and not a probability.</p>
      </section>

      {result.product && (
        <section className="card">
          <h3>Registered product</h3>
          <dl className="kv" style={{ marginTop: '.75rem' }}>
            <dt>Product</dt><dd>{result.product.name}</dd>
            <dt>Brand</dt><dd>{result.product.brand}</dd>
            <dt>Barcode</dt><dd className="mono">{result.product.gtin}</dd>
            {result.product.batchCode && <><dt>Batch</dt><dd><span className="mono">{result.product.batchCode}</span> <StatusPill value={result.product.batchStatus} /></dd></>}
            {result.product.expiresOn && <><dt>Expiry</dt><dd>{result.product.expiresOn}</dd></>}
          </dl>
        </section>
      )}

      <section className="card">
        <h3>Why we gave this rating</h3>
        <SignalList signals={result.signals} />
      </section>

      <section className="card stack">
        <h3>Checks performed</h3>
        <div className="checks">
          {result.checks.map((c) => (
            <span key={c.key} className={`pill ${c.ran ? 'ok' : 'neutral'}`}>{c.ran ? <CheckCircle2 size={14} /> : <MinusCircle size={14} />} {c.label}{c.ran ? '' : ' (not run)'}</span>
          ))}
        </div>
        {imageSkipped && <p className="small muted">{imageSkipped.note || 'No packaging photo was added.'} <Link to="/verify">Run another check with a photo.</Link></p>}
        {positives.length > 0 && <p className="small muted">Reassuring signals: {positives.map((p) => p.title).join(', ')}.</p>}
      </section>

      <section className="card">
        <h3>What to do next</h3>
        <ul className="muted" style={{ paddingLeft: '1.1rem' }}>{result.recommendedActions.map((a) => <li key={a}>{a}</li>)}</ul>
      </section>

      {warnings && (warnings.alerts.length > 0 || warnings.reportCount > 0) && (
        <section className="card stack">
          <h3>Previous warnings for this code</h3>
          <p className="small muted">{warnings.totalScans} checks recorded, {warnings.flaggedScans} flagged, {warnings.reportCount} consumer report(s).</p>
          <div className="table-wrap"><table><thead><tr><th>When</th><th>Warning</th><th>Status</th></tr></thead><tbody>
            {warnings.alerts.map((a) => <tr key={a.id}><td>{fmtDate(a.createdAt)}</td><td>{a.summary}</td><td><StatusPill value={a.status} /></td></tr>)}
          </tbody></table></div>
        </section>
      )}

      <Disclaimer items={result.limitations} />

      <div className="row">
        <Link className="btn" to="/verify">Check another product</Link>
        {tone !== 'ok' && <Link className="btn secondary" to="/report" state={{ identifier: result.identifier, productName: result.product?.name }}>Report this product</Link>}
        <Link className="btn ghost" to="/history">View history</Link>
      </div>
    </div>
  );
}
