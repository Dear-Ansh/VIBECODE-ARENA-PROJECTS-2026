import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { api } from '../api/client.js';
import ImagePicker from '../components/ImagePicker.jsx';
import { StatusPill } from '../components/Badges.jsx';

export default function Report() {
  const loc = useLocation();
  const [f, setF] = useState({ productName: loc.state?.productName || '', identifier: loc.state?.identifier || '', purchaseLocation: '', purchaseDate: '', price: '', currency: 'USD', description: '', contact: '' });
  const [images, setImages] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [fields, setFields] = useState({});
  const [done, setDone] = useState(null);
  const [track, setTrack] = useState({ id: '', data: null, error: '' });
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setError(''); setFields({});
    try { setDone(await api.submitReport({ ...f, images })); }
    catch (err) { setError(err.message); setFields(Object.fromEntries((err.fields || []).map((x) => [x.field, x.message]))); }
    setBusy(false);
  };
  const lookup = async (e) => {
    e.preventDefault();
    try { setTrack({ ...track, data: await api.trackReport(track.id.trim()), error: '' }); } catch (err) { setTrack({ ...track, data: null, error: err.message }); }
  };
  const Err = ({ k }) => fields[k] ? <div className="error-text">{fields[k]}</div> : null;

  if (done) return (
    <div className="narrow stack">
      <div className="alert ok"><strong>Report received.</strong> Your reference number is <span className="mono">{done.id}</span>. Save it to track progress. Keep the packaging and receipt.</div>
      <Link className="btn" to="/">Back to home</Link>
    </div>
  );

  return (
    <div className="narrow stack-lg">
      <div><h2>Report a suspected counterfeit</h2><p className="muted">Tell us what you found. Reports are reviewed by an administrator. This prototype stores them as simulated data.</p></div>
      <form className="card stack" onSubmit={submit} noValidate>
        <div className="field"><label htmlFor="pn">Product name</label><input id="pn" value={f.productName} onChange={set('productName')} /><Err k="productName" /></div>
        <div className="field"><label htmlFor="ic">Code on the pack <span className="hint">(optional)</span></label><input id="ic" className="mono" value={f.identifier} onChange={set('identifier')} /></div>
        <div className="grid cols-2">
          <div className="field"><label htmlFor="pl">Where did you buy it?</label><input id="pl" value={f.purchaseLocation} onChange={set('purchaseLocation')} placeholder="Shop, website or market" /><Err k="purchaseLocation" /></div>
          <div className="field"><label htmlFor="pd">Purchase date</label><input id="pd" type="date" value={f.purchaseDate} onChange={set('purchaseDate')} /></div>
        </div>
        <div className="grid cols-2">
          <div className="field"><label htmlFor="pr">Price paid</label><input id="pr" type="number" min="0" step="0.01" value={f.price} onChange={set('price')} /></div>
          <div className="field"><label htmlFor="ct">Contact <span className="hint">(optional, email or phone)</span></label><input id="ct" value={f.contact} onChange={set('contact')} /></div>
        </div>
        <div className="field"><label htmlFor="ds">What looks wrong?</label><textarea id="ds" value={f.description} onChange={set('description')} placeholder="For example: misspelled brand name, missing seal, blurry print" /><Err k="description" /></div>
        <div className="field"><label>Photos of the product and packaging <span className="hint">(up to 4)</span></label><ImagePicker multiple files={images} onChange={setImages} /></div>
        {error && <div className="alert bad" role="alert">{error}</div>}
        <button className="btn" disabled={busy}>{busy ? 'Sending' : 'Send report'}</button>
      </form>

      <form className="card stack" onSubmit={lookup}>
        <h3>Track a report</h3>
        <div className="row"><input style={{ flex: '1 1 220px' }} className="mono" aria-label="Report reference" placeholder="rep_ab12cd34ef" value={track.id} onChange={(e) => setTrack({ ...track, id: e.target.value })} /><button className="btn secondary">Check status</button></div>
        {track.data && <p>Status: <StatusPill value={track.data.status} /></p>}
        {track.error && <div className="alert warn">{track.error}</div>}
      </form>
    </div>
  );
}
