import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ScanLine, ArrowRight, ImagePlus, History } from 'lucide-react';
import Disclaimer from '../components/Disclaimer.jsx';

export default function Home() {
  const [code, setCode] = useState('');
  const nav = useNavigate();
  const go = (e) => { e.preventDefault(); nav('/verify', { state: { identifier: code } }); };

  return (
    <div className="container stack-lg">
      <section className="hero">
        <div>
          <h1>Is this product the real thing?</h1>
          <p className="lead">Scan the QR code or barcode, or type the product code. TrustMark checks it against registered products, looks for copied codes, and explains every warning in plain language.</p>
          <form className="check-box" onSubmit={go}>
            <input aria-label="Product code" placeholder="TM-GS-0001-AB12" value={code} onChange={(e) => setCode(e.target.value)} />
            <button className="btn" type="submit">Check product</button>
            <Link className="btn secondary" to="/verify" state={{ mode: 'scan' }}><ScanLine size={18} /> Scan code</Link>
          </form>
          <div className="samples">
            <span className="small muted">Sample codes:</span>
            {['TM-GS-0001-AB12', 'TM-CW-0042-XK77', 'TM-GS-0002-CD34'].map((c) => <button key={c} className="chip mono" onClick={() => setCode(c)}>{c}</button>)}
          </div>
        </div>

        <div className="evidence" aria-label="Example result">
          <header><span>Example check</span><span className="mono">TM-CW-0042-XK77</span></header>
          <ul>
            <li><i className="dot bad" /><div><strong>Single-use code scanned again</strong><p className="small muted">Earlier scans came from 5 other devices.</p></div></li>
            <li><i className="dot bad" /><div><strong>Impossible travel</strong><p className="small muted">Delhi to Dubai in under 2 hours.</p></div></li>
            <li><i className="dot warn" /><div><strong>Unusually many scans</strong><p className="small muted">7 scans in 24 hours.</p></div></li>
            <li><i className="dot info" /><div><strong>Result: Potentially counterfeit</strong><p className="small muted">An indicator, not proof.</p></div></li>
          </ul>
        </div>
      </section>

      <section className="steps">
        <div className="card"><h3>Check the code</h3><p className="muted small">Scan with your camera or type it. We validate the format and look it up in the registry.</p></div>
        <div className="card"><h3>Add a packaging photo</h3><p className="muted small">Optional. We compare logos, colours, layout and label spelling with the brand's reference images.</p></div>
        <div className="card"><h3>Read the explanation</h3><p className="muted small">You get a clear rating and the exact reasons, plus what to do next.</p></div>
      </section>

      <section className="grid cols-2">
        <div className="card"><div className="row"><History size={20} /><h3>Your check history</h3></div><p className="muted small" style={{ marginTop: '.5rem' }}>Every check on this device is saved so you can revisit warnings. <Link to="/history">Open history</Link></p></div>
        <div className="card"><div className="row"><ImagePlus size={20} /><h3>Found a fake?</h3></div><p className="muted small" style={{ marginTop: '.5rem' }}>Send photos and purchase details to the review team. <Link to="/report">Report a product</Link></p></div>
      </section>

      <Disclaimer title="Please keep in mind" />
    </div>
  );
}
