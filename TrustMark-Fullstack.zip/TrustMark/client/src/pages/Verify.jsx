import { useEffect, useState, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Keyboard, ScanLine, Image as ImageIcon, Loader2 } from 'lucide-react';
import { api } from '../api/client.js';
import { getDeviceId } from '../utils/device.js';
import { SCENARIOS, SAMPLE_PHOTOS, loadSample, extractCode } from '../utils/samples.js';
import Scanner from '../components/Scanner.jsx';
import ImagePicker from '../components/ImagePicker.jsx';
import Disclaimer from '../components/Disclaimer.jsx';

const CITIES = ['Delhi', 'Mumbai', 'Bengaluru', 'Chennai', 'Kolkata', 'Hyderabad', 'Dubai'];

export default function Verify() {
  const loc = useLocation();
  const nav = useNavigate();
  const [mode, setMode] = useState(loc.state?.mode === 'scan' ? 'scan' : 'type');
  const [identifier, setIdentifier] = useState(loc.state?.identifier || '');
  const [batch, setBatch] = useState('');
  const [city, setCity] = useState('Delhi');
  const [labelText, setLabelText] = useState('');
  const [images, setImages] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const onScan = useCallback((text) => { setIdentifier(extractCode(text)); setMode('type'); }, []);

  const submit = async (override) => {
    const v = { identifier, batch, city, labelText, image: images[0], ...override };
    if (!v.identifier.trim()) { setError('Enter or scan a code first.'); return; }
    setBusy(true); setError('');
    try {
      const result = await api.verify({ identifier: v.identifier, batch: v.batch, city: v.city, labelText: v.labelText, deviceId: getDeviceId(), image: v.image });
      sessionStorage.setItem('trustmark.lastResult', JSON.stringify(result));
      nav('/result', { state: { result, hadImage: Boolean(v.image) } });
    } catch (e) { setError(e.message); setBusy(false); }
  };

  const runScenario = async (s) => {
    const image = s.photo ? await loadSample(s.photo) : undefined;
    setIdentifier(s.identifier); setBatch(s.batch || ''); setCity(s.city); setLabelText(s.labelText || ''); setImages(image ? [image] : []);
    submit({ identifier: s.identifier, batch: s.batch || '', city: s.city, labelText: s.labelText || '', image });
  };

  useEffect(() => { if (loc.state?.identifier) window.history.replaceState({}, ''); }, [loc.state]);

  return (
    <div className="narrow stack-lg">
      <div><h2>Check a product</h2><p className="muted">Start with the code. Add a packaging photo for a stronger check.</p></div>

      <div className="card stack">
        <div className="tabs" role="tablist" aria-label="Input method">
          <button role="tab" aria-selected={mode === 'type'} onClick={() => setMode('type')}><Keyboard size={16} /> Type code</button>
          <button role="tab" aria-selected={mode === 'scan'} onClick={() => setMode('scan')}><ScanLine size={16} /> Scan with camera</button>
        </div>

        {mode === 'scan' ? <Scanner onResult={onScan} /> : (
          <form className="stack" onSubmit={(e) => { e.preventDefault(); submit(); }}>
            <div className="field">
              <label htmlFor="id">Product code or barcode</label>
              <input id="id" className="mono" value={identifier} onChange={(e) => setIdentifier(e.target.value)} placeholder="TM-GS-0001-AB12 or 8901234567890" autoComplete="off" />
            </div>
            <div className="grid cols-2">
              <div className="field"><label htmlFor="batch">Batch number <span className="hint">(printed on pack, optional)</span></label>
                <input id="batch" value={batch} onChange={(e) => setBatch(e.target.value)} placeholder="GS-2406-A" /></div>
              <div className="field"><label htmlFor="city">Where are you? <span className="hint">(simulated)</span></label>
                <select id="city" value={city} onChange={(e) => setCity(e.target.value)}>{CITIES.map((c) => <option key={c}>{c}</option>)}</select></div>
            </div>

            <details>
              <summary style={{ cursor: 'pointer', fontWeight: 600 }}><ImageIcon size={16} style={{ verticalAlign: '-3px' }} /> Add packaging photo and label text (optional)</summary>
              <div className="stack" style={{ marginTop: '1rem' }}>
                <ImagePicker files={images} onChange={setImages} samples={SAMPLE_PHOTOS} />
                <div className="field"><label htmlFor="lt">Text on the label <span className="hint">(brand name, product name, as printed)</span></label>
                  <input id="lt" value={labelText} onChange={(e) => setLabelText(e.target.value)} placeholder="GlowSkin Vitamin C Serum" /></div>
              </div>
            </details>

            {error && <div className="alert bad" role="alert">{error}</div>}
            <button className="btn" disabled={busy}>{busy ? <><span className="spinner" /> Checking</> : 'Check product'}</button>
          </form>
        )}
      </div>

      <section className="stack">
        <h3>Try a demo scenario</h3>
        <div className="grid cols-3">
          {SCENARIOS.map((s) => (
            <button key={s.title} className="card flat" style={{ textAlign: 'left', cursor: 'pointer', font: 'inherit' }} disabled={busy} onClick={() => runScenario(s)}>
              <strong>{s.title}</strong><p className="small muted">{s.note}</p>
            </button>
          ))}
        </div>
        <p className="small muted">Demo scenarios add a check to your history and to the sample scan data.</p>
      </section>
      <Disclaimer />
    </div>
  );
}
