export const SAMPLE_PHOTOS = [
  { id: 'glowskin-genuine', label: 'GlowSkin genuine', url: '/samples/glowskin-front.svg' },
  { id: 'glowskin-fake', label: 'GlowSkin fake', url: '/samples/glowskin-fake.svg' },
  { id: 'curawell-genuine', label: 'CuraWell genuine', url: '/samples/curawell-front.svg' },
  { id: 'curawell-fake', label: 'CuraWell fake', url: '/samples/curawell-fake.svg' }
];

// One-click demo scenarios (sample data only)
export const SCENARIOS = [
  { title: 'Genuine product', identifier: 'TM-GS-0001-AB12', city: 'Delhi', note: 'Registered, active batch, normal scans.' },
  { title: 'Unknown code', identifier: 'TM-XX-9999-ZZ00', city: 'Delhi', note: 'Not in the registry.' },
  { title: 'Invalid input', identifier: '12345', city: 'Delhi', note: 'Fails format checks.' },
  { title: 'Copied QR code', identifier: 'TM-CW-0042-XK77', city: 'Dubai', note: 'Single-use code scanned many times, far apart.' },
  { title: 'Wrong batch', identifier: 'TM-GS-0001-AB12', batch: 'GS-2405-B', city: 'Delhi', note: 'Printed batch does not match the registry.' },
  { title: 'Fake packaging', identifier: 'TM-GS-0001-AB12', city: 'Delhi', photo: 'glowskin-fake', labelText: 'GlowSkIn Vitamin C Serum', note: 'Photo and label spelling differ.' },
  { title: 'Recalled batch', identifier: 'TM-CW-0900-RC03', city: 'Delhi', note: 'Manufacturer safety recall.' },
  { title: 'Revoked code', identifier: 'TM-GS-0002-CD34', city: 'Delhi', note: 'Revoked by the brand.' },
  { title: 'Barcode only', identifier: '8901234567890', city: 'Delhi', note: 'Retail barcode with no unique serial.' }
];

async function svgToPng(blob) {
  const url = URL.createObjectURL(blob);
  const img = await new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = url; });
  const canvas = document.createElement('canvas');
  canvas.width = 400; canvas.height = 500;
  canvas.getContext('2d').drawImage(img, 0, 0, 400, 500);
  URL.revokeObjectURL(url);
  return new Promise((res) => canvas.toBlob(res, 'image/png'));
}

export async function loadSample(id) {
  const s = SAMPLE_PHOTOS.find((x) => x.id === id);
  const blob = await (await fetch(s.url)).blob();
  return new File([await svgToPng(blob)], `${s.id}.png`, { type: 'image/png' });
}

// QR codes often hold a URL; pull out the TrustMark code if present.
export function extractCode(text) {
  const m = String(text).toUpperCase().match(/TM-[A-Z]{2,4}-\d{4}-[A-Z0-9]{4}/);
  return m ? m[0] : String(text).trim();
}
