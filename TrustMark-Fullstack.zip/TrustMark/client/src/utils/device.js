// Anonymous per-browser id so scan history can be grouped without accounts.
export function getDeviceId() {
  let id = localStorage.getItem('trustmark.device');
  if (!id) {
    id = `dev-${crypto.randomUUID().slice(0, 12)}`;
    localStorage.setItem('trustmark.device', id);
  }
  return id;
}

export const fmtDate = (iso) => new Date(iso).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

export const BAND_META = {
  'Likely Genuine': { tone: 'ok', short: 'Likely genuine' },
  'Needs Further Verification': { tone: 'warn', short: 'Needs verification' },
  'Potentially Counterfeit': { tone: 'bad', short: 'Potentially counterfeit' }
};
