export default function RiskGauge({ score }) {
  return (
    <div>
      <div className="gauge" role="img" aria-label={`Risk score ${score} out of 100`}>
        <div className="marker" style={{ left: `${Math.min(99, Math.max(1, score))}%` }}><span>{score}</span></div>
      </div>
      <div className="gauge-scale"><span>Low risk</span><span>Needs checking</span><span>High risk</span></div>
    </div>
  );
}
