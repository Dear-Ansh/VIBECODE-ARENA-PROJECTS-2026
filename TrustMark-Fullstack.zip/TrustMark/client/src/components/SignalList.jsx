import { AlertTriangle, CheckCircle2, Info } from 'lucide-react';

const ICON = { high: <AlertTriangle size={20} color="#b42318" />, medium: <AlertTriangle size={20} color="#9a6200" />, low: <Info size={20} color="#9a6200" />, info: <CheckCircle2 size={20} color="#1b7f4b" /> };

export default function SignalList({ signals }) {
  return (
    <div>
      {signals.map((s) => (
        <div className="signal" key={s.key}>
          <span aria-hidden>{ICON[s.severity]}</span>
          <div>
            <strong>{s.title}</strong>
            <p className="muted small">{s.reason}</p>
          </div>
          <span className={`pts ${s.points > 0 ? 'plus' : 'minus'}`} title="Effect on risk score">{s.points > 0 ? '+' : ''}{s.points}</span>
        </div>
      ))}
    </div>
  );
}
