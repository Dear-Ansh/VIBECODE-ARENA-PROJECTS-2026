import { Info } from 'lucide-react';

export const DEFAULT_LIMITS = [
  'QR codes and barcodes can be copied exactly. A registry match shows a code exists, not that this item is real.',
  'Image comparison depends on lighting and angle and cannot prove authenticity.',
  'The risk score is a rule-based indicator, not a probability and not proof.'
];

export default function Disclaimer({ items = DEFAULT_LIMITS, title = 'What this result cannot tell you' }) {
  return (
    <aside className="disclaimer" aria-label={title}>
      <div className="row"><Info size={18} color="#0b7a75" /><strong>{title}</strong></div>
      <ul className="small muted">{items.map((t) => <li key={t}>{t}</li>)}</ul>
    </aside>
  );
}
