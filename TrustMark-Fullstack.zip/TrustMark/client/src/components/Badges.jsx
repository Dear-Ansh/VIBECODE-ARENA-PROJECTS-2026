import { BAND_META } from '../utils/device.js';

export function VerdictPill({ band }) {
  const meta = BAND_META[band] || { tone: 'neutral', short: band };
  return <span className={`pill ${meta.tone}`}>{meta.short}</span>;
}

export const StatusPill = ({ value }) => {
  const tone = { active: 'ok', confirmed: 'ok', resolved: 'ok', expired: 'warn', under_review: 'warn', acknowledged: 'warn', medium: 'warn', recalled: 'bad', revoked: 'bad', high: 'bad', open: 'bad', new: 'bad', dismissed: 'neutral', low: 'neutral' }[value] || 'neutral';
  return <span className={`pill ${tone}`}>{String(value).replace('_', ' ')}</span>;
};
