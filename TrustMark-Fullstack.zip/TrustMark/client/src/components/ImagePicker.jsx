import { useRef } from 'react';
import { Camera, Upload, X } from 'lucide-react';
import { loadSample } from '../utils/samples.js';

// Single or multiple image selection with camera capture on phones.
export default function ImagePicker({ files, onChange, multiple = false, max = 4, samples = [] }) {
  const inputRef = useRef(null);
  const add = (list) => {
    const next = multiple ? [...files, ...list].slice(0, max) : list.slice(0, 1);
    onChange(next);
  };
  const useSample = async (s) => add([await loadSample(s.id)]);

  return (
    <div className="dropzone">
      <div className="row" style={{ justifyContent: 'center' }}>
        <button type="button" className="btn secondary small" onClick={() => inputRef.current.click()}><Upload size={16} /> Upload photo</button>
        <button type="button" className="btn secondary small" onClick={() => { inputRef.current.setAttribute('capture', 'environment'); inputRef.current.click(); inputRef.current.removeAttribute('capture'); }}><Camera size={16} /> Take photo</button>
      </div>
      <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" multiple={multiple} hidden
        onChange={(e) => { add([...e.target.files]); e.target.value = ''; }} />
      <p className="small muted" style={{ marginTop: '.5rem' }}>JPG, PNG or WebP, up to 5 MB{multiple ? ` each (max ${max})` : ''}.</p>
      {files.length > 0 && (
        <div className="thumbs" style={{ justifyContent: 'center' }}>
          {files.map((f, i) => (
            <div key={i} style={{ position: 'relative' }}>
              <img src={URL.createObjectURL(f)} alt={`Selected ${i + 1}`} />
              <button type="button" aria-label="Remove image" onClick={() => onChange(files.filter((_, j) => j !== i))}
                style={{ position: 'absolute', top: -6, right: -6, border: 0, borderRadius: '50%', width: 22, height: 22, background: '#0e1b2c', color: '#fff', cursor: 'pointer', display: 'grid', placeItems: 'center' }}><X size={12} /></button>
            </div>
          ))}
        </div>
      )}
      {samples.length > 0 && (
        <div className="samples" style={{ justifyContent: 'center' }}>
          <span className="small muted">Try a sample photo:</span>
          {samples.map((s) => <button type="button" key={s.id} className="chip" onClick={() => useSample(s)}>{s.label}</button>)}
        </div>
      )}
    </div>
  );
}
