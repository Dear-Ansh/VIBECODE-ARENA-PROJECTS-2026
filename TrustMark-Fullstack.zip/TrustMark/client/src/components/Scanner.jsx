// Camera QR/barcode scanner built on html5-qrcode.
import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats as F } from 'html5-qrcode';

export default function Scanner({ onResult }) {
  const [error, setError] = useState('');
  const scannerRef = useRef(null);
  const doneRef = useRef(false);

  useEffect(() => {
    const scanner = new Html5Qrcode('scanner-region', {
      formatsToSupport: [F.QR_CODE, F.EAN_13, F.EAN_8, F.UPC_A, F.CODE_128, F.DATA_MATRIX],
      verbose: false
    });
    scannerRef.current = scanner;
    scanner
      .start({ facingMode: 'environment' }, { fps: 10, qrbox: { width: 240, height: 240 } }, (text) => {
        if (doneRef.current) return;
        doneRef.current = true;
        onResult(text);
      }, () => {})
      .catch(() => setError('Camera not available. Allow camera access, or type the code instead.'));
    return () => {
      const s = scannerRef.current;
      if (s?.isScanning) s.stop().then(() => s.clear()).catch(() => {});
    };
  }, [onResult]);

  return (
    <div className="stack">
      <div id="scanner-region" />
      {error && <div className="alert warn">{error}</div>}
      <p className="small muted">Point the camera at the QR code or barcode. If the code contains a web link, only the TrustMark code part is used.</p>
    </div>
  );
}
