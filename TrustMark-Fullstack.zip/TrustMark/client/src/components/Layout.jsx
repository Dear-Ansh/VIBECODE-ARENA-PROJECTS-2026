import { useState } from 'react';
import { NavLink, Outlet, Link } from 'react-router-dom';
import { ShieldCheck, Menu } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';

export default function Layout() {
  const [open, setOpen] = useState(false);
  const { user } = useAuth();
  const close = () => setOpen(false);
  return (
    <>
      <header className="site-header">
        <div className="container">
          <Link to="/" className="brand" onClick={close}><ShieldCheck size={26} color="#14b8a6" /> TrustMark</Link>
          <button className="menu-btn" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)}><Menu size={20} /></button>
          <nav className={`nav ${open ? 'open' : ''}`} aria-label="Main">
            <NavLink to="/verify" onClick={close}>Check a product</NavLink>
            <NavLink to="/history" onClick={close}>My checks</NavLink>
            <NavLink to="/report" onClick={close}>Report a fake</NavLink>
            <NavLink to={user ? '/admin' : '/admin/login'} onClick={close}>{user ? 'Dashboard' : 'Admin sign in'}</NavLink>
          </nav>
        </div>
      </header>
      <main><Outlet /></main>
      <footer className="site-footer">
        <div className="container">
          TrustMark is a prototype using sample data. Results are indicators, not proof of authenticity. Barcodes and QR codes can be copied.
        </div>
      </footer>
    </>
  );
}
