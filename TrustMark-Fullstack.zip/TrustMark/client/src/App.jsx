import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import Home from './pages/Home.jsx';
import Verify from './pages/Verify.jsx';
import Result from './pages/Result.jsx';
import History from './pages/History.jsx';
import Report from './pages/Report.jsx';
import Login from './pages/admin/Login.jsx';
import AdminLayout from './pages/admin/AdminLayout.jsx';
import Dashboard from './pages/admin/Dashboard.jsx';
import Alerts from './pages/admin/Alerts.jsx';
import Reports from './pages/admin/Reports.jsx';
import Registry from './pages/admin/Registry.jsx';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="verify" element={<Verify />} />
        <Route path="result" element={<Result />} />
        <Route path="history" element={<History />} />
        <Route path="report" element={<Report />} />
        <Route path="admin/login" element={<Login />} />
        <Route path="admin" element={<ProtectedRoute><AdminLayout /></ProtectedRoute>}>
          <Route index element={<Dashboard />} />
          <Route path="alerts" element={<Alerts />} />
          <Route path="reports" element={<Reports />} />
          <Route path="registry" element={<Registry />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
