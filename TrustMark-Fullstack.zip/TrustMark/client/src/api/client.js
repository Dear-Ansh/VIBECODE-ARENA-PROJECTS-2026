// One place for all network calls. Components never use fetch directly.
const TOKEN_KEY = 'trustmark.token';

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => (t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY));

async function request(path, { method = 'GET', body, form, auth = false } = {}) {
  const headers = {};
  if (auth && getToken()) headers.Authorization = `Bearer ${getToken()}`;
  if (body) headers['Content-Type'] = 'application/json';
  let res;
  try {
    res = await fetch(`/api${path}`, { method, headers, body: form || (body ? JSON.stringify(body) : undefined) });
  } catch {
    throw new Error('Cannot reach the TrustMark server. Check that it is running and try again.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Request failed.');
    err.status = res.status; err.fields = data.fields;
    throw err;
  }
  return data;
}

const toForm = (obj) => {
  const f = new FormData();
  Object.entries(obj).forEach(([k, v]) => {
    if (v === undefined || v === null || v === '') return;
    if (Array.isArray(v)) v.forEach((item) => f.append(k, item)); else f.append(k, v);
  });
  return f;
};

export const api = {
  verify: (fields) => request('/verify', { method: 'POST', form: toForm(fields) }),
  warnings: (token) => request(`/verify/warnings/${encodeURIComponent(token)}`),
  history: (deviceId) => request(`/verify/history?deviceId=${encodeURIComponent(deviceId)}`),
  cities: () => request('/verify/cities'),
  submitReport: (fields) => request('/reports', { method: 'POST', form: toForm(fields) }),
  trackReport: (id) => request(`/reports/track/${encodeURIComponent(id)}`),

  login: (email, password) => request('/auth/login', { method: 'POST', body: { email, password } }),
  admin: {
    stats: () => request('/admin/stats', { auth: true }),
    registry: () => request('/admin/registry', { auth: true }),
    createBrand: (b) => request('/admin/brands', { method: 'POST', body: b, auth: true }),
    createProduct: (p) => request('/admin/products', { method: 'POST', body: p, auth: true }),
    updateProduct: (id, p) => request(`/admin/products/${id}`, { method: 'PUT', body: p, auth: true }),
    uploadReference: (id, files) => request(`/admin/products/${id}/images`, { method: 'POST', form: toForm({ images: files }), auth: true }),
    createBatch: (b) => request('/admin/batches', { method: 'POST', body: b, auth: true }),
    updateBatch: (id, b) => request(`/admin/batches/${id}`, { method: 'PATCH', body: b, auth: true }),
    createIdentifier: (i) => request('/admin/identifiers', { method: 'POST', body: i, auth: true }),
    updateIdentifier: (id, i) => request(`/admin/identifiers/${id}`, { method: 'PATCH', body: i, auth: true }),
    reports: () => request('/admin/reports', { auth: true }),
    updateReport: (id, patch) => request(`/admin/reports/${id}`, { method: 'PATCH', body: patch, auth: true }),
    alerts: () => request('/admin/alerts', { auth: true }),
    updateAlert: (id, status) => request(`/admin/alerts/${id}`, { method: 'PATCH', body: { status }, auth: true })
  }
};
