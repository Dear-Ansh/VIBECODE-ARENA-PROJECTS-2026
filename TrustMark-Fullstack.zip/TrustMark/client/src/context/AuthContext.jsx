import { createContext, useContext, useState, useCallback } from 'react';
import { api, getToken, setToken } from '../api/client.js';

const AuthContext = createContext(null);
const USER_KEY = 'trustmark.user';

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => (getToken() ? JSON.parse(localStorage.getItem(USER_KEY) || 'null') : null));

  const login = useCallback(async (email, password) => {
    const { token, user: u } = await api.login(email, password);
    setToken(token); localStorage.setItem(USER_KEY, JSON.stringify(u)); setUser(u);
  }, []);
  const logout = useCallback(() => { setToken(null); localStorage.removeItem(USER_KEY); setUser(null); }, []);

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
