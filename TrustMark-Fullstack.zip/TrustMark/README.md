# TrustMark: Smart Counterfeit Product Detection Platform

A full-stack prototype (React + Node/Express) that checks product identifiers, flags suspicious codes,
compares packaging photos with reference images and explains every result in plain language.

> **Important:** Barcodes and QR codes can be copied. Image comparison and automated risk scores are
> indicators only and can never prove a product is genuine. The app says this on every result.

## Quick start

```bash
npm install          # installs both workspaces (server + client)
npm run dev          # API on :5000, React app on :5173
```
Open http://localhost:5173. Sample data is created automatically on first run (`npm run seed -w server` resets it).

Admin sign in: `admin@trustmark.demo` / `Admin@123` (change in `server/.env`).

Requires Node 18+. Tests: `npm test` (risk-engine unit tests, no database needed).

## Folder structure

```text
trustmark/
├── package.json              npm workspaces + dev scripts
├── docs/ARCHITECTURE.md      data model, API list, risk rules
├── server/
│   ├── .env.example
│   ├── uploads/reference/    brand reference images (sample SVGs included)
│   ├── uploads/reports/      consumer report photos
│   └── src/
│       ├── index.js / app.js        entry + Express setup (helmet, CORS, rate limit)
│       ├── config/                  env + risk thresholds (tune here)
│       ├── data/db.js, seed.js      JSON datastore + sample records
│       ├── middleware/              auth (JWT), uploads (multer), error handling
│       ├── routes/                  auth, verify, reports, admin
│       ├── services/
│       │   ├── riskEngine.js        pure, explainable scoring
│       │   ├── verificationService  lookup, history, alerts, orchestration
│       │   ├── imageService.js      dHash + colour histogram (sharp)
│       │   └── textCheckService.js  label spelling / missing keywords
│       ├── utils/                   validators (GTIN, token), geo, ids
│       └── tests/riskEngine.test.js
└── client/
    ├── vite.config.js        dev proxy to the API
    ├── public/samples/       sample genuine and fake packaging images
    └── src/
        ├── api/client.js     all network calls
        ├── context/          auth state
        ├── components/       Layout, Scanner, ImagePicker, RiskGauge, SignalList, Disclaimer...
        ├── pages/            Home, Verify, Result, History, Report
        ├── pages/admin/      Login, Dashboard, Alerts, Reports, Registry
        └── utils/            device id, demo scenarios
```

## Feature map (against the problem statement)

| Requirement | Where |
|---|---|
| Scan QR/barcode, or type an identifier | `Scanner.jsx` (html5-qrcode), `Verify.jsx` |
| Check against registered products | `verificationService.js`, `data/seed.js` |
| Flag unknown/invalid identifiers | `validators.js` (format + GTIN check digit), `riskEngine.js` |
| Detect repeated/suspicious codes | scan burst, many devices, many cities, impossible travel, single-use reuse |
| Upload/capture packaging images | `ImagePicker.jsx` (camera capture on phones) |
| Compare logos, labels, spelling | `imageService.js` (layout + colour), `textCheckService.js` (spelling) |
| Explainable 3-level result | `riskEngine.js` returns signals, points, checks run, actions |
| Product records and admin updates | `routes/admin.js`, `Registry.jsx` (brands, products, batches, codes, reference images) |
| Consumer reports | `Report.jsx`, `routes/reports.js` (photos, purchase details, tracking number) |
| Admin dashboard | `Dashboard.jsx`, `Reports.jsx`, `Alerts.jsx`, audit log |
| Verification history + previous warnings | `History.jsx`, `GET /api/verify/warnings/:token` |
| Limitations communicated | `Disclaimer.jsx` on every page that shows a result |

## Beyond the first prototype

- Admin sign in with JWT and role check; audit log of admin actions
- Alerts are created automatically from scan behaviour and managed by admins
- Recalled batches and revoked codes with a safety notice
- Report triage priority (reports about alerted codes are marked high)
- Zod validation, rate limiting, upload type/size limits, helmet headers
- Risk engine is a pure function with unit tests

## Using a real database

All data access goes through `server/src/data/db.js` (`all`, `find`, `filter`, `insert`, `update`, `remove`).
Replace that file with a MongoDB, Supabase or Firebase adapter exposing the same functions
(make them async and add `await` in the services/routes) and nothing else needs to change.

## Optional extensions

- OCR with `tesseract.js` to read label text from the photo and feed `checkLabelText`
- OpenCV.js / a pre-trained model for logo detection
- Real geolocation instead of the city selector
- Cloud storage (S3 / Supabase Storage) for report images
