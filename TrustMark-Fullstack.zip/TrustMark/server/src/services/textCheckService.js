// Compares text the user typed from the label (or OCR output, if you add
// tesseract.js later) with the product's expected keywords.
import { editDistance } from '../utils/validators.js';

const tokenize = (s) => s.split(/[^A-Za-z0-9]+/).filter((w) => w.length > 2);

export function checkLabelText(text, expectedKeywords = []) {
  if (!text || !text.trim()) return null;
  const words = tokenize(text);
  const lowerWords = words.map((w) => w.toLowerCase());
  const misspelled = [];
  const missing = [];

  for (const keyword of expectedKeywords) {
    const parts = tokenize(keyword);
    for (const part of parts) {
      const exact = words.find((w) => w === part);
      if (exact) continue; // exact, case-sensitive match (catches GlowSkIn vs GlowSkin)
      // Near match: same word within 2 edits, or differing only in letter case
      const near = words.find((w) => {
        const d = editDistance(w.toLowerCase(), part.toLowerCase());
        return d <= 2 && (d > 0 || w !== part);
      });
      if (near) misspelled.push({ expected: part, found: near });
      else if (!lowerWords.includes(part.toLowerCase())) missing.push(part);
    }
  }
  return { misspelled, missing };
}
