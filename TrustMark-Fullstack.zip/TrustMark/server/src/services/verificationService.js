import { db } from '../data/db.js';
import { config } from '../config/index.js';
import { classifyIdentifier } from '../utils/validators.js';
import { newId } from '../utils/id.js';
import { assess, BANDS } from './riskEngine.js';
import { compareWithReferences } from './imageService.js';
import { checkLabelText } from './textCheckService.js';

function lookup(classification) {
  let identifier = null, product = null, batch = null;
  if (classification.type === 'token') {
    identifier = db.find('identifiers', (i) => i.token === classification.value) || null;
    batch = identifier ? db.find('batches', (b) => b.id === identifier.batchId) : null;
    product = batch ? db.find('products', (p) => p.id === batch.productId) : null;
  } else if (classification.type === 'gtin') {
    product = db.find('products', (p) => p.gtin === classification.value) || null;
  }
  const brand = product ? db.find('brands', (b) => b.id === product.brandId) : null;
  return { identifier, batch, product, brand };
}

const ALERT_FOR = {
  impossible_travel: 'Impossible travel between scans.',
  scan_burst: 'Unusually many scans in a short time.',
  single_use_reused: 'Single-use code scanned by multiple devices.',
  recalled_batch: 'Scan on a recalled batch.',
  revoked_identifier: 'Scan on a revoked identifier.'
};

function raiseAlerts(token, result) {
  if (!token) return;
  for (const s of result.signals) {
    const ruleKey = s.key === 'single_use_reused' ? 'single_use_reused' : s.key;
    if (!ALERT_FOR[ruleKey]) continue;
    const exists = db.find('alerts', (a) => a.token === token && a.ruleKey === ruleKey && a.status === 'open');
    if (!exists) db.insert('alerts', { id: newId('alt'), ruleKey, severity: s.severity, token, summary: s.reason, status: 'open', createdAt: new Date().toISOString() });
  }
}

export async function verify({ identifier: raw, batch: batchEntered, city = 'Delhi', deviceId = 'anonymous', imageBuffer, labelText }) {
  const at = new Date().toISOString();
  const classification = classifyIdentifier(raw);
  const found = lookup(classification);
  const history = found.identifier ? db.filter('scans', (s) => s.identifierId === found.identifier.id) : [];
  const openAlerts = classification.type === 'token' ? db.filter('alerts', (a) => a.token === classification.value && a.status !== 'resolved') : [];

  const image = imageBuffer && found.product ? await compareWithReferences(imageBuffer, found.product.referenceImages) : imageBuffer ? { available: false, reason: 'No registered product to compare with.' } : null;
  const text = checkLabelText(labelText, found.product?.expectedKeywords);

  const result = assess({ classification, ...found, history, current: { at, city, deviceId }, batchEntered, image, labelText: text, openAlerts });

  const scan = {
    id: newId('scan'), identifierId: found.identifier?.id || null, token: classification.value, inputType: classification.type,
    at, city, deviceId, verdict: result.band, score: result.score, productName: result.product?.name || null,
    topSignals: result.signals.filter((s) => s.points > 0).slice(0, 3).map((s) => s.title)
  };
  db.insert('scans', scan);
  raiseAlerts(found.identifier ? classification.value : null, result);

  return { scanId: scan.id, identifier: classification.value, inputType: classification.type, scannedAt: at, ...result };
}

export function previousWarnings(token) {
  const value = classifyIdentifier(token).value;
  const alerts = db.filter('alerts', (a) => a.token === value);
  const reports = db.filter('reports', (r) => r.identifier === value);
  const scans = db.filter('scans', (s) => s.token === value);
  return {
    token: value,
    totalScans: scans.length,
    flaggedScans: scans.filter((s) => s.verdict !== BANDS.GENUINE).length,
    alerts: alerts.map(({ id, ruleKey, severity, summary, status, createdAt }) => ({ id, ruleKey, severity, summary, status, createdAt })),
    reportCount: reports.length
  };
}
