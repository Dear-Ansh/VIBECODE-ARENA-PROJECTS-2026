// Pure, explainable scoring. No database or network access here, so it is
// easy to unit-test. Every signal carries a plain-language reason + evidence.
import { config } from '../config/index.js';
import { CITIES, haversineKm } from '../utils/geo.js';

export const BANDS = {
  GENUINE: 'Likely Genuine',
  VERIFY: 'Needs Further Verification',
  COUNTERFEIT: 'Potentially Counterfeit'
};

export const LIMITATIONS = [
  'QR codes and barcodes can be copied exactly. A registry match shows the code exists, not that this physical item is real.',
  'Image comparison depends on lighting, angle and photo quality, and can miss careful copies or flag genuine items.',
  'The risk score is a rule-based indicator, not a probability and not proof. Treat it as one piece of evidence.'
];

const sig = (key, severity, points, title, reason, evidence = {}) => ({ key, severity, points, title, reason, evidence });

export function assess(ctx) {
  const t = config.risk;
  const signals = [];
  const checks = [];
  let override = null; // 'counterfeit' | 'verify'
  let safetyAlert = false;

  const { classification, identifier, batch, product, brand, history = [], current, batchEntered, image, labelText, openAlerts = [] } = ctx;

  // ---- 1. Format / registry checks ------------------------------------
  checks.push({ key: 'format', label: 'Identifier format', ran: true });
  if (classification.type === 'invalid') {
    signals.push(sig('invalid_format', 'medium', 40, 'Invalid identifier', classification.reason, { input: classification.value }));
  }

  checks.push({ key: 'registry', label: 'Registry lookup', ran: classification.type !== 'invalid' });
  if (classification.type === 'token' && !identifier) {
    signals.push(sig('unknown_identifier', 'medium', 45, 'Code not in registry',
      'This code is not in the sample registry. Many genuine brands are not registered yet, so this is not proof of a fake, but it cannot be confirmed either.', { token: classification.value }));
  }
  if (classification.type === 'gtin' && !product) {
    signals.push(sig('unknown_gtin', 'medium', 40, 'Barcode not in registry', 'This barcode number is not linked to any registered product.', { gtin: classification.value }));
  }
  if (classification.type === 'gtin' && product) {
    signals.push(sig('gtin_only', 'low', 25, 'Barcode only',
      'Retail barcodes are identical on every unit and are easy to copy. This confirms the product exists, not that this unit is genuine. Scan the TrustMark QR code or add a packaging photo for a stronger check.', { gtin: product.gtin }));
  }

  // ---- 2. Identifier / batch status -----------------------------------
  if (identifier?.status === 'revoked') {
    signals.push(sig('revoked_identifier', 'high', 100, 'Code revoked by brand',
      `The brand owner revoked this code${identifier.revokedReason ? `: ${identifier.revokedReason}` : '.'}`, { revokedAt: identifier.revokedAt }));
    override = 'counterfeit';
  }
  if (batch?.status === 'recalled') {
    signals.push(sig('recalled_batch', 'high', 40, 'Recalled batch',
      `Batch ${batch.batchCode} was recalled by the manufacturer${batch.recallReason ? ` (${batch.recallReason})` : ''}. This is a safety issue even if the item is genuine.`, { batchCode: batch.batchCode }));
    safetyAlert = true;
    override = override || 'verify';
  }
  if (batch?.status === 'expired' || (batch?.expiresOn && new Date(batch.expiresOn) < new Date())) {
    signals.push(sig('expired_batch', 'medium', 30, 'Batch past expiry', `Batch ${batch.batchCode} expired on ${batch.expiresOn}.`, { expiresOn: batch.expiresOn }));
  }
  if (batchEntered && batch && batchEntered.trim().toUpperCase() !== batch.batchCode) {
    signals.push(sig('batch_mismatch', 'high', 35, 'Batch number mismatch',
      `You entered ${batchEntered.trim().toUpperCase()} but this code is registered to ${batch.batchCode}.`, { entered: batchEntered, registered: batch.batchCode }));
  }

  // ---- 3. Scan behaviour ---------------------------------------------
  checks.push({ key: 'history', label: 'Scan history', ran: Boolean(identifier) });
  if (identifier) {
    const windowStart = new Date(current.at).getTime() - t.burstWindowHours * 3600 * 1000;
    const recent = history.filter((s) => new Date(s.at).getTime() >= windowStart);
    const devices = new Set([...recent.map((s) => s.deviceId), current.deviceId]);
    const cities = new Set([...recent.map((s) => s.city), current.city]);
    const otherDeviceScans = history.filter((s) => s.deviceId !== current.deviceId);

    if (identifier.singleUse && otherDeviceScans.length >= 1) {
      signals.push(sig('single_use_reused', 'high', 35, 'Single-use code scanned again',
        `This code is meant to be used once, but ${otherDeviceScans.length} earlier scan(s) came from other devices. A copied code is a likely cause.`, { priorScans: history.length }));
    }
    // Only scans from OTHER devices count, so one person re-checking is not flagged
    const othersRecent = recent.filter((s) => s.deviceId !== current.deviceId);
    if (othersRecent.length + 1 >= t.burstScanThreshold) {
      signals.push(sig('scan_burst', 'high', 30, 'Unusually many scans',
        `This code was scanned ${othersRecent.length + 1} times by different devices in the last ${t.burstWindowHours} hours.`, { scans: othersRecent.length + 1, windowHours: t.burstWindowHours }));
    }
    if (devices.size >= t.deviceThreshold) {
      signals.push(sig('many_devices', 'medium', 20, 'Scanned by many devices', `${devices.size} different devices scanned this code recently.`, { devices: devices.size }));
    }
    if (cities.size >= 3) {
      signals.push(sig('many_cities', 'medium', 15, 'Scanned in many places', `Scans came from ${cities.size} cities: ${[...cities].join(', ')}.`, { cities: [...cities] }));
    }
    const last = [...history].sort((a, b) => new Date(b.at) - new Date(a.at))[0];
    if (last && last.city !== current.city && CITIES[last.city] && CITIES[current.city]) {
      const hours = Math.max((new Date(current.at) - new Date(last.at)) / 3600000, 1 / 60);
      const km = haversineKm(CITIES[last.city], CITIES[current.city]);
      const speed = km / hours;
      if (speed > t.impossibleTravelKmh) {
        signals.push(sig('impossible_travel', 'high', 40, 'Impossible travel',
          `Last scan was in ${last.city}, now ${current.city}: about ${Math.round(km)} km apart in ${Math.round(hours * 60)} minutes.`, { km: Math.round(km), minutes: Math.round(hours * 60), kmh: Math.round(speed) }));
      }
    }
    if (openAlerts.length) {
      signals.push(sig('prior_warnings', 'medium', 10, 'Earlier warnings on this code',
        `${openAlerts.length} unresolved warning(s) already exist for this code.`, { alerts: openAlerts.map((a) => a.ruleKey) }));
    }
  }

  // ---- 4. Packaging image --------------------------------------------
  checks.push({ key: 'image', label: 'Packaging image', ran: Boolean(image?.available), note: image && !image.available ? image.reason : undefined });
  let imageStrong = false;
  if (image?.available) {
    if (image.hammingDistance >= t.hashDistanceFail) {
      signals.push(sig('image_mismatch', 'high', 35, 'Packaging looks different',
        `Layout similarity to the reference is low (difference ${image.hammingDistance}/64).`, image));
    } else if (image.hammingDistance >= t.hashDistanceWarn) {
      signals.push(sig('image_partial', 'medium', 20, 'Packaging partly differs',
        `Some layout differences from the reference (difference ${image.hammingDistance}/64). Lighting or angle may also cause this.`, image));
    } else imageStrong = true;
    if (image.colorSimilarity < t.colorSimilarityWarn) {
      signals.push(sig('color_mismatch', 'medium', 10, 'Brand colours differ', `Colour match with the reference is ${Math.round(image.colorSimilarity * 100)}%.`, image));
      imageStrong = false;
    }
  }

  // ---- 5. Label text --------------------------------------------------
  checks.push({ key: 'text', label: 'Label spelling', ran: Boolean(labelText) });
  if (labelText?.misspelled?.length) {
    const pts = Math.min(40, labelText.misspelled.length * 25);
    signals.push(sig('spelling_error', 'high', pts, 'Spelling differs from official text',
      labelText.misspelled.map((m) => `"${m.found}" instead of "${m.expected}"`).join('; ') + '.', labelText));
  }
  if (labelText?.missing?.length) {
    signals.push(sig('missing_text', 'medium', Math.min(20, labelText.missing.length * 10), 'Expected text not found',
      `Not found on the label: ${labelText.missing.join(', ')}.`, labelText));
  }

  // ---- 6. Positive evidence ------------------------------------------
  const negatives = signals.filter((s) => s.points > 0);
  if (identifier && negatives.length === 0) {
    signals.push(sig('registry_match', 'info', -15, 'Registered and consistent', 'The code is registered, the batch is active and scan activity looks normal.', { batch: batch?.batchCode }));
  }
  if (imageStrong) {
    signals.push(sig('image_match', 'info', -10, 'Packaging matches reference', `Packaging photo closely matches the reference image (difference ${image.hammingDistance}/64).`, image));
  }

  // ---- 7. Score and band ---------------------------------------------
  const score = Math.min(100, Math.max(0, signals.reduce((n, s) => n + s.points, 0)));
  let band = BANDS.GENUINE;
  if (override === 'counterfeit' || score >= t.counterfeitFrom) band = BANDS.COUNTERFEIT;
  else if (override === 'verify' || score >= t.genuineBelow) band = BANDS.VERIFY;

  return {
    score, band, safetyAlert,
    signals: signals.sort((a, b) => b.points - a.points),
    checks,
    limitations: LIMITATIONS,
    recommendedActions: actionsFor(band, safetyAlert),
    product: product ? {
      id: product.id, name: product.name, category: product.category, brand: brand?.name, gtin: product.gtin,
      batchCode: batch?.batchCode, expiresOn: batch?.expiresOn, batchStatus: batch?.status
    } : null
  };
}

function actionsFor(band, safety) {
  const base = band === BANDS.GENUINE
    ? ['Check the tamper seal and printing quality on the box.', 'Make sure the batch number on the pack matches the result.']
    : band === BANDS.VERIFY
      ? ['Compare the packaging with the brand\'s official website.', 'Ask the seller for an invoice or contact the brand directly.', 'Add a packaging photo and label text for a stronger check.']
      : ['Do not use or consume this product until it has been checked by the brand.', 'Report it using the Report page and keep the packaging and receipt.', 'Contact the brand or local consumer authority.'];
  return safety ? ['Stop using this product: its batch was recalled.', ...base] : base;
}
