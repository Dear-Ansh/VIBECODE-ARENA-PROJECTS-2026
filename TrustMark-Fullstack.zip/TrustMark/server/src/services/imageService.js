// Lightweight packaging-image comparison using `sharp` (no ML model needed).
//  - dHash: 64-bit perceptual hash of structure/layout (lower distance = more similar)
//  - Colour histogram intersection: compares overall brand colours
// These are heuristics. They cannot prove or disprove authenticity.
import path from 'node:path';
import sharp from 'sharp';
import { config } from '../config/index.js';

const cache = new Map();

export async function dHash(input) {
  const { data } = await sharp(input).rotate().resize(9, 8, { fit: 'fill' }).grayscale().raw().toBuffer({ resolveWithObject: true });
  const bits = [];
  for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) bits.push(data[y * 9 + x] > data[y * 9 + x + 1] ? 1 : 0);
  return bits;
}

export async function colorHistogram(input) {
  const { data } = await sharp(input).rotate().resize(32, 32, { fit: 'fill' }).removeAlpha().raw().toBuffer({ resolveWithObject: true });
  const bins = new Array(64).fill(0);
  for (let i = 0; i < data.length; i += 3) {
    bins[((data[i] >> 6) << 4) | ((data[i + 1] >> 6) << 2) | (data[i + 2] >> 6)]++;
  }
  const total = data.length / 3;
  return bins.map((b) => b / total);
}

export const hamming = (a, b) => a.reduce((n, bit, i) => n + (bit !== b[i] ? 1 : 0), 0);
export const histIntersection = (a, b) => a.reduce((s, v, i) => s + Math.min(v, b[i]), 0);

async function fingerprint(file) {
  if (!cache.has(file)) cache.set(file, Promise.all([dHash(file), colorHistogram(file)]).then(([hash, hist]) => ({ hash, hist })));
  return cache.get(file);
}

/**
 * Compare an uploaded buffer with a product's reference images.
 * Returns the BEST match across references, or { available:false, reason } on failure.
 */
export async function compareWithReferences(buffer, referenceFiles = []) {
  if (!referenceFiles.length) return { available: false, reason: 'This product has no reference images yet.' };
  try {
    const [hash, hist] = await Promise.all([dHash(buffer), colorHistogram(buffer)]);
    let best = null;
    for (const file of referenceFiles) {
      const ref = await fingerprint(path.join(config.uploadsDir, 'reference', file));
      const candidate = { reference: file, hammingDistance: hamming(hash, ref.hash), colorSimilarity: Number(histIntersection(hist, ref.hist).toFixed(3)) };
      if (!best || candidate.hammingDistance < best.hammingDistance) best = candidate;
    }
    return { available: true, ...best };
  } catch (err) {
    return { available: false, reason: `The image could not be analysed (${err.message}).` };
  }
}
