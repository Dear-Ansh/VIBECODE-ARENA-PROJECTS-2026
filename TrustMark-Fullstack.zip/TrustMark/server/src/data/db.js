// Tiny JSON-file datastore. Swap this module for MongoDB/Supabase/Firebase
// later: the rest of the app only uses the functions exported here.
import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config/index.js';

const COLLECTIONS = ['users', 'brands', 'products', 'batches', 'identifiers', 'scans', 'alerts', 'reports', 'auditLog'];
let state = null;
let writeTimer = null;

function empty() {
  return Object.fromEntries(COLLECTIONS.map((c) => [c, []]));
}

export function load() {
  if (state) return state;
  try {
    state = { ...empty(), ...JSON.parse(fs.readFileSync(config.dbFile, 'utf8')) };
  } catch {
    state = empty();
  }
  return state;
}

export function replaceAll(next) {
  state = { ...empty(), ...next };
  flush();
}

export function flush() {
  clearTimeout(writeTimer);
  fs.mkdirSync(path.dirname(config.dbFile), { recursive: true });
  fs.writeFileSync(config.dbFile, JSON.stringify(state, null, 2));
}

function persist() {
  clearTimeout(writeTimer);
  writeTimer = setTimeout(flush, 150);
}

export const db = {
  all: (c) => load()[c],
  find: (c, pred) => load()[c].find(pred),
  filter: (c, pred) => load()[c].filter(pred),
  insert(c, doc) { load()[c].push(doc); persist(); return doc; },
  update(c, id, patch) {
    const doc = load()[c].find((d) => d.id === id);
    if (!doc) return null;
    Object.assign(doc, patch, { updatedAt: new Date().toISOString() });
    persist();
    return doc;
  },
  remove(c, id) {
    const arr = load()[c];
    const i = arr.findIndex((d) => d.id === id);
    if (i === -1) return false;
    arr.splice(i, 1); persist(); return true;
  },
  save: persist
};
