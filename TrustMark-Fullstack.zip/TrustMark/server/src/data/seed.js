// Sample data for the prototype. Run `npm run seed` to reset.
import bcrypt from 'bcryptjs';
import { config } from '../config/index.js';
import { load, replaceAll } from './db.js';

const hoursAgo = (h) => new Date(Date.now() - h * 3600 * 1000).toISOString();
const daysAgo = (d) => hoursAgo(d * 24);
const now = new Date().toISOString();

function buildSeed() {
  const scan = (identifierId, token, h, city, device, verdict, score) => ({
    id: `scan_${Math.random().toString(36).slice(2, 9)}`,
    identifierId, token, at: hoursAgo(h), city, deviceId: device, verdict, score
  });

  return {
    users: [{
      id: 'u_admin', email: config.adminEmail, name: 'Admin Operator', role: 'admin',
      passwordHash: bcrypt.hashSync(config.adminPassword, 10), createdAt: now
    }],
    brands: [
      { id: 'b1', name: 'GlowSkin Labs', website: 'https://glowskin.example', createdAt: now },
      { id: 'b2', name: 'CuraWell Pharma', website: 'https://curawell.example', createdAt: now },
      { id: 'b3', name: 'VoltEdge Electronics', website: 'https://voltedge.example', createdAt: now }
    ],
    products: [
      { id: 'p1', brandId: 'b1', name: 'GlowSkin Vitamin C Serum 30 ml', category: 'cosmetics', gtin: '8901234567890',
        referenceImages: ['glowskin-front.svg'], expectedKeywords: ['GlowSkin', 'Vitamin C', 'Serum'], createdAt: now },
      { id: 'p2', brandId: 'b2', name: 'CuraWell Paracetamol 500 mg', category: 'medicine', gtin: '8901234500011',
        referenceImages: ['curawell-front.svg'], expectedKeywords: ['CuraWell', 'Paracetamol', 'Pharma'], createdAt: now },
      { id: 'p3', brandId: 'b3', name: 'VoltEdge 20,000 mAh Power Bank', category: 'electronics', gtin: '8901234500028',
        referenceImages: ['voltedge-front.svg'], expectedKeywords: ['VoltEdge', 'Power Bank', 'Electronics'], createdAt: now }
    ],
    batches: [
      { id: 'bt1', productId: 'p1', batchCode: 'GS-2406-A', manufacturedOn: '2026-06-12', expiresOn: '2028-06-11', status: 'active' },
      { id: 'bt2', productId: 'p1', batchCode: 'GS-2401-B', manufacturedOn: '2026-01-20', expiresOn: '2026-09-30', status: 'expired' },
      { id: 'bt3', productId: 'p2', batchCode: 'CW-2605-K', manufacturedOn: '2026-05-03', expiresOn: '2028-05-02', status: 'active' },
      { id: 'bt4', productId: 'p2', batchCode: 'CW-2511-Q', manufacturedOn: '2025-11-08', expiresOn: '2027-11-07', status: 'recalled', recallReason: 'Quality deviation found in tablet coating.' },
      { id: 'bt5', productId: 'p3', batchCode: 'VE-2607-C', manufacturedOn: '2026-07-01', expiresOn: '2031-07-01', status: 'active' }
    ],
    identifiers: [
      { id: 'i1', batchId: 'bt1', token: 'TM-GS-0001-AB12', status: 'active', singleUse: false },
      { id: 'i2', batchId: 'bt3', token: 'TM-CW-0042-XK77', status: 'active', singleUse: true },
      { id: 'i3', batchId: 'bt4', token: 'TM-CW-0900-RC03', status: 'active', singleUse: false },
      { id: 'i4', batchId: 'bt1', token: 'TM-GS-0002-CD34', status: 'revoked', singleUse: false, revokedAt: daysAgo(3), revokedReason: 'Reported cloned by brand owner.' },
      { id: 'i5', batchId: 'bt5', token: 'TM-VE-0007-PQ90', status: 'active', singleUse: false },
      { id: 'i6', batchId: 'bt2', token: 'TM-GS-0003-EF56', status: 'active', singleUse: false }
    ],
    // Prior scan history. TM-CW-0042-XK77 is a "cloned" single-use code.
    scans: [
      scan('i1', 'TM-GS-0001-AB12', 70, 'Delhi', 'dev-aaa', 'Likely Genuine', 5),
      scan('i2', 'TM-CW-0042-XK77', 6, 'Delhi', 'dev-d1', 'Likely Genuine', 10),
      scan('i2', 'TM-CW-0042-XK77', 5.7, 'Mumbai', 'dev-d2', 'Needs Further Verification', 45),
      scan('i2', 'TM-CW-0042-XK77', 5, 'Mumbai', 'dev-d3', 'Needs Further Verification', 50),
      scan('i2', 'TM-CW-0042-XK77', 4, 'Chennai', 'dev-d4', 'Potentially Counterfeit', 70),
      scan('i2', 'TM-CW-0042-XK77', 3, 'Kolkata', 'dev-d5', 'Potentially Counterfeit', 78),
      scan('i2', 'TM-CW-0042-XK77', 2, 'Delhi', 'dev-d6', 'Potentially Counterfeit', 85),
      scan('i4', 'TM-GS-0002-CD34', 40, 'Hyderabad', 'dev-x1', 'Potentially Counterfeit', 100),
      scan('i3', 'TM-CW-0900-RC03', 30, 'Bengaluru', 'dev-r1', 'Potentially Counterfeit', 75)
    ],
    alerts: [
      { id: 'alt_1', ruleKey: 'impossible_travel', severity: 'high', token: 'TM-CW-0042-XK77', summary: 'Same code scanned in Delhi and Mumbai 18 minutes apart.', status: 'open', createdAt: hoursAgo(5.7) },
      { id: 'alt_2', ruleKey: 'scan_burst', severity: 'medium', token: 'TM-CW-0042-XK77', summary: 'Single-use medicine code scanned 6 times by 6 devices in 24 hours.', status: 'open', createdAt: hoursAgo(2) },
      { id: 'alt_3', ruleKey: 'recalled_batch', severity: 'high', token: 'TM-CW-0900-RC03', summary: 'Scan attempt on recalled batch CW-2511-Q.', status: 'open', createdAt: hoursAgo(30) },
      { id: 'alt_4', ruleKey: 'revoked_identifier', severity: 'high', token: 'TM-GS-0002-CD34', summary: 'Scan attempt on a revoked identifier.', status: 'acknowledged', createdAt: hoursAgo(40) }
    ],
    reports: [
      { id: 'rep_1', productName: 'GlowSkin Vitamin C Serum', identifier: 'TM-GS-0002-CD34', purchaseLocation: 'Online marketplace', price: 12, currency: 'USD',
        description: 'Label says "GlowSkIn" and the safety seal was missing.', images: [], status: 'under_review', priority: 'high', notes: [], contact: 'simulated@example.com', createdAt: daysAgo(2) },
      { id: 'rep_2', productName: 'CuraWell Paracetamol', identifier: 'TM-CW-0042-XK77', purchaseLocation: 'Local pharmacy, Mumbai', price: 2.5, currency: 'USD',
        description: 'Expired date sticker placed over the printed expiry date.', images: [], status: 'new', priority: 'high', notes: [], contact: 'simulated@example.com', createdAt: daysAgo(1) },
      { id: 'rep_3', productName: 'VoltEdge Power Bank', identifier: '', purchaseLocation: 'Street vendor, Dubai', price: 9, currency: 'USD',
        description: 'Capacity feels far lower than 20,000 mAh and logo is slightly different.', images: [], status: 'confirmed', priority: 'medium', notes: [{ at: daysAgo(1), by: 'Admin Operator', text: 'Matches known fake VoItEdge print run.' }], contact: '', createdAt: daysAgo(4) }
    ],
    auditLog: []
  };
}

export function seedIfEmpty() {
  const s = load();
  if (s.users.length === 0) { replaceAll(buildSeed()); console.log('[seed] sample data created'); }
}

if (process.argv[1] && process.argv[1].endsWith('seed.js')) {
  replaceAll(buildSeed());
  console.log('[seed] database reset with sample data');
}
