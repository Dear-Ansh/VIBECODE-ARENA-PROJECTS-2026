import multer from 'multer';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config/index.js';

const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const filter = (_req, file, cb) => IMAGE_TYPES.includes(file.mimetype) ? cb(null, true) : cb(new Error('Only JPG, PNG or WebP images are allowed.'));
const limits = { fileSize: 5 * 1024 * 1024, files: 4 };

// Verification photos are analysed in memory and never stored.
export const memoryUpload = multer({ storage: multer.memoryStorage(), fileFilter: filter, limits });

const diskFor = (folder) => multer({
  storage: multer.diskStorage({
    destination: path.join(config.uploadsDir, folder),
    filename: (_req, file, cb) => cb(null, `${Date.now()}-${crypto.randomBytes(4).toString('hex')}${path.extname(file.originalname).toLowerCase() || '.jpg'}`)
  }),
  fileFilter: filter, limits
});
export const reportUpload = diskFor('reports');
export const referenceUpload = diskFor('reference');
