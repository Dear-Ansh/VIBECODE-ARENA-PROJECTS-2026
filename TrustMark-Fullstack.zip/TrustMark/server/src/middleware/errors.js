import { ZodError } from 'zod';

export const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
export const notFound = (_req, res) => res.status(404).json({ error: 'Not found.' });

export function errorHandler(err, _req, res, _next) {
  if (err instanceof ZodError) {
    return res.status(400).json({ error: 'Some fields need attention.', fields: err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })) });
  }
  if (err.name === 'MulterError' || /images are allowed/.test(err.message)) {
    return res.status(400).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'Each image must be 5 MB or smaller.' : err.message });
  }
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on our side. Please try again.' });
}
