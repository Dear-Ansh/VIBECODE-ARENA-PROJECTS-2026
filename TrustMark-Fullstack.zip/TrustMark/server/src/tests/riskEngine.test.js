import { test } from 'node:test';
import assert from 'node:assert/strict';
import { assess, BANDS } from '../services/riskEngine.js';
import { classifyIdentifier, isValidGtin } from '../utils/validators.js';
import { checkLabelText } from '../services/textCheckService.js';

const NOW = new Date('2026-10-24T10:00:00Z');
const mins = (m) => new Date(NOW.getTime() - m * 60000).toISOString();
const batch = { batchCode: 'GS-2406-A', status: 'active', expiresOn: '2028-06-11' };
const product = { id: 'p1', name: 'Serum', category: 'cosmetics', gtin: '8901234567890' };
const base = (over = {}) => ({
  classification: { type: 'token', value: 'TM-GS-0001-AB12' },
  identifier: { id: 'i1', status: 'active', singleUse: false }, batch, product, brand: { name: 'GlowSkin' },
  history: [], current: { at: NOW.toISOString(), city: 'Delhi', deviceId: 'me' }, ...over
});

test('genuine: registered, active, quiet history', () => {
  const r = assess(base());
  assert.equal(r.band, BANDS.GENUINE);
  assert.ok(r.signals.some((s) => s.key === 'registry_match'));
});

test('unknown token needs verification, never "counterfeit" on its own', () => {
  const r = assess(base({ identifier: null, batch: null, product: null }));
  assert.equal(r.band, BANDS.VERIFY);
});

test('invalid format is flagged', () => {
  const r = assess({ classification: classifyIdentifier('12345'), history: [], current: { at: NOW.toISOString(), city: 'Delhi', deviceId: 'x' } });
  assert.equal(r.band, BANDS.VERIFY);
  assert.equal(r.signals[0].key, 'invalid_format');
});

test('revoked identifier is counterfeit regardless of score', () => {
  assert.equal(assess(base({ identifier: { id: 'i', status: 'revoked' } })).band, BANDS.COUNTERFEIT);
});

test('recalled batch raises a safety alert', () => {
  const r = assess(base({ batch: { ...batch, status: 'recalled' } }));
  assert.equal(r.safetyAlert, true);
  assert.notEqual(r.band, BANDS.GENUINE);
});

test('cloned single-use code with impossible travel is potentially counterfeit', () => {
  const history = [
    { at: mins(30), city: 'Mumbai', deviceId: 'a' }, { at: mins(25), city: 'Mumbai', deviceId: 'b' }, { at: mins(20), city: 'Mumbai', deviceId: 'c' }
  ];
  const r = assess(base({ identifier: { id: 'i2', status: 'active', singleUse: true }, history }));
  assert.equal(r.band, BANDS.COUNTERFEIT);
  const keys = r.signals.map((s) => s.key);
  for (const k of ['single_use_reused', 'impossible_travel', 'scan_burst']) assert.ok(keys.includes(k), k);
});

test('batch mismatch adds a warning', () => {
  const r = assess(base({ batchEntered: 'GS-2405-B' }));
  assert.ok(r.signals.some((s) => s.key === 'batch_mismatch'));
  assert.equal(r.band, BANDS.VERIFY);
});

test('barcode alone is never "Likely Genuine"', () => {
  const r = assess({ classification: { type: 'gtin', value: product.gtin }, product, brand: { name: 'x' }, history: [], current: { at: NOW.toISOString(), city: 'Delhi', deviceId: 'x' } });
  assert.equal(r.band, BANDS.VERIFY);
});

test('image mismatch + spelling error pushes towards counterfeit', () => {
  const r = assess(base({
    image: { available: true, hammingDistance: 26, colorSimilarity: 0.4 },
    labelText: { misspelled: [{ expected: 'GlowSkin', found: 'GlowSkIn' }], missing: [] }
  }));
  assert.equal(r.band, BANDS.COUNTERFEIT);
});

test('every result carries limitations and checks', () => {
  const r = assess(base());
  assert.equal(r.limitations.length, 3);
  assert.ok(r.checks.length >= 4);
});

test('GTIN check digit validation', () => {
  assert.ok(isValidGtin('8901234567890'));
  assert.ok(!isValidGtin('8901234567891'));
});

test('label spelling detects case-swapped brand', () => {
  const r = checkLabelText('GlowSkIn Vitamin C Serum', ['GlowSkin', 'Vitamin C']);
  assert.deepEqual(r.misspelled.map((m) => m.found), ['GlowSkIn']);
});
