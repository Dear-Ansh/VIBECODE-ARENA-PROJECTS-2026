import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(__dirname, '../..');

export const config = {
  port: Number(process.env.PORT) || 5000,
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  jwtSecret: process.env.JWT_SECRET || 'dev-secret',
  adminEmail: process.env.ADMIN_EMAIL || 'admin@trustmark.demo',
  adminPassword: process.env.ADMIN_PASSWORD || 'Admin@123',
  dbFile: path.join(ROOT, 'data', 'db.json'),
  uploadsDir: path.join(ROOT, 'uploads'),
  // Risk thresholds - kept here so they are easy to tune and document
  risk: {
    genuineBelow: 25,
    counterfeitFrom: 55,
    burstWindowHours: 24,
    burstScanThreshold: 4,
    deviceThreshold: 3,
    impossibleTravelKmh: 900,
    hashDistanceWarn: 12,
    hashDistanceFail: 22,
    colorSimilarityWarn: 0.8
  }
};
