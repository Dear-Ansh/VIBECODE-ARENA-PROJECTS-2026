import { createApp } from './app.js';
import { config } from './config/index.js';
import { seedIfEmpty } from './data/seed.js';

seedIfEmpty();
createApp().listen(config.port, () => {
  console.log(`TrustMark API running on http://localhost:${config.port}`);
  console.log(`Demo admin: ${config.adminEmail} / ${config.adminPassword}`);
});
