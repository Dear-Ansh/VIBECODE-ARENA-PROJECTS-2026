// TrustMark token format: TM-<2-4 letters>-<4 digits>-<4 alphanumerics>
export const TOKEN_RE = /^TM-[A-Z]{2,4}-\d{4}-[A-Z0-9]{4}$/;

export function normalizeIdentifier(raw = '') {
  return String(raw).trim().toUpperCase().replace(/\s+/g, '');
}

// GS1 check digit validation for GTIN-8/12/13/14
export function isValidGtin(code) {
  if (!/^\d{8}$|^\d{12,14}$/.test(code)) return false;
  const digits = code.split('').map(Number);
  const check = digits.pop();
  let sum = 0;
  digits.reverse().forEach((d, i) => { sum += d * (i % 2 === 0 ? 3 : 1); });
  return (10 - (sum % 10)) % 10 === check;
}

export function classifyIdentifier(raw) {
  const value = normalizeIdentifier(raw);
  if (TOKEN_RE.test(value)) return { type: 'token', value };
  if (/^\d+$/.test(value)) {
    const lengthOk = /^\d{8}$|^\d{12,14}$/.test(value);
    if (isValidGtin(value)) return { type: 'gtin', value };
    return {
      type: 'invalid',
      value,
      reason: lengthOk ? 'The barcode check digit is wrong, which usually means a typo or a fake number.' : 'The number length does not match a barcode (8, 12, 13 or 14 digits).'
    };
  }
  return { type: 'invalid', value, reason: 'This does not match the TrustMark code format (TM-XX-0000-XXXX) or a numeric barcode.' };
}

// Levenshtein distance for spelling / brand-name checks
export function editDistance(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, (_, i) => [i, ...Array(n).fill(0)]);
  for (let j = 1; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return dp[m][n];
}
