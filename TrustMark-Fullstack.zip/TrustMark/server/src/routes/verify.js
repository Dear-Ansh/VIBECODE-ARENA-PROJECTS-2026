import { Router } from 'express';
import { z } from 'zod';
import { memoryUpload } from '../middleware/upload.js';
import { asyncHandler } from '../middleware/errors.js';
import { verify, previousWarnings } from '../services/verificationService.js';
import { CITIES } from '../utils/geo.js';
import { db } from '../data/db.js';

const router = Router();
const body = z.object({
  identifier: z.string().trim().min(1, 'Enter or scan a code.').max(64),
  batch: z.string().trim().max(32).optional(),
  city: z.string().refine((c) => c in CITIES, 'Choose a listed city.').optional(),
  deviceId: z.string().max(64).optional(),
  labelText: z.string().max(500).optional()
});

router.post('/', memoryUpload.single('image'), asyncHandler(async (req, res) => {
  const input = body.parse(req.body);
  res.json(await verify({ ...input, imageBuffer: req.file?.buffer }));
}));

router.get('/warnings/:token', (req, res) => res.json(previousWarnings(req.params.token)));

// Verification history for one browser/device
router.get('/history', (req, res) => {
  const deviceId = String(req.query.deviceId || '');
  if (!deviceId) return res.json({ scans: [] });
  const scans = db.filter('scans', (s) => s.deviceId === deviceId).sort((a, b) => new Date(b.at) - new Date(a.at)).slice(0, 50);
  res.json({ scans });
});

router.get('/cities', (_req, res) => res.json({ cities: Object.keys(CITIES) }));
export default router;
