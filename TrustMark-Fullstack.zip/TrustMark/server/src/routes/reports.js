import { Router } from 'express';
import { z } from 'zod';
import { reportUpload } from '../middleware/upload.js';
import { db } from '../data/db.js';
import { newId } from '../utils/id.js';
import { normalizeIdentifier } from '../utils/validators.js';

const router = Router();
const schema = z.object({
  productName: z.string().trim().min(2, 'Enter the product name.').max(120),
  identifier: z.string().trim().max(64).optional().default(''),
  purchaseLocation: z.string().trim().min(2, 'Tell us where you bought it.').max(160),
  purchaseDate: z.string().optional(),
  price: z.coerce.number().min(0).max(1e7).optional(),
  currency: z.string().max(5).optional().default('USD'),
  description: z.string().trim().min(10, 'Describe what looks wrong (at least 10 characters).').max(1500),
  contact: z.string().trim().max(120).optional().default('')
});

router.post('/', reportUpload.array('images', 4), (req, res) => {
  const input = schema.parse(req.body);
  const identifier = normalizeIdentifier(input.identifier);
  // Priority is a simple triage hint: a code with active alerts jumps the queue
  const flagged = identifier && db.find('alerts', (a) => a.token === identifier && a.status === 'open');
  const report = db.insert('reports', {
    id: newId('rep'), ...input, identifier, images: (req.files || []).map((f) => f.filename),
    status: 'new', priority: flagged ? 'high' : 'medium', notes: [], createdAt: new Date().toISOString()
  });
  res.status(201).json({ id: report.id, status: report.status, message: 'Report received. Keep your packaging and receipt.' });
});

// Consumers can check progress with the reference number
router.get('/track/:id', (req, res) => {
  const r = db.find('reports', (x) => x.id === req.params.id);
  if (!r) return res.status(404).json({ error: 'No report found with that reference.' });
  res.json({ id: r.id, status: r.status, createdAt: r.createdAt, updatedAt: r.updatedAt });
});

export default router;
