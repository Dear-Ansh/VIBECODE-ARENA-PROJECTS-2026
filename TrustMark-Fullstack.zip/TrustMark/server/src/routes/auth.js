import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { db } from '../data/db.js';
import { signToken, requireAdmin } from '../middleware/auth.js';

const router = Router();
const schema = z.object({ email: z.string().email(), password: z.string().min(1) });

router.post('/login', (req, res) => {
  const { email, password } = schema.parse(req.body);
  const user = db.find('users', (u) => u.email.toLowerCase() === email.toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) return res.status(401).json({ error: 'Email or password is incorrect.' });
  res.json({ token: signToken(user), user: { id: user.id, name: user.name, email: user.email, role: user.role } });
});

router.get('/me', requireAdmin, (req, res) => res.json({ user: req.user }));
export default router;
