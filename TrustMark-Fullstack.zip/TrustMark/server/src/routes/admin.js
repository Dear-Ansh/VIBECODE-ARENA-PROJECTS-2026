import { Router } from 'express';
import { z } from 'zod';
import { requireAdmin } from '../middleware/auth.js';
import { referenceUpload } from '../middleware/upload.js';
import { db } from '../data/db.js';
import { newId } from '../utils/id.js';
import { isValidGtin, TOKEN_RE } from '../utils/validators.js';
import { BANDS } from '../services/riskEngine.js';

const router = Router();
router.use(requireAdmin);

const audit = (req, action, target) => db.insert('auditLog', { id: newId('log'), at: new Date().toISOString(), by: req.user.name, action, target });

// ---------- Registry ------------------------------------------------------
router.get('/registry', (_req, res) => res.json({
  brands: db.all('brands'), products: db.all('products'), batches: db.all('batches'), identifiers: db.all('identifiers')
}));

router.post('/brands', (req, res) => {
  const { name, website } = z.object({ name: z.string().trim().min(2), website: z.string().url().optional() }).parse(req.body);
  const brand = db.insert('brands', { id: newId('b'), name, website, createdAt: new Date().toISOString() });
  audit(req, 'brand.create', brand.name);
  res.status(201).json(brand);
});

const productSchema = z.object({
  brandId: z.string(),
  name: z.string().trim().min(2).max(120),
  category: z.enum(['cosmetics', 'medicine', 'electronics', 'clothing', 'food', 'other']),
  gtin: z.string().refine(isValidGtin, 'Enter a valid GTIN (8, 12, 13 or 14 digits with correct check digit).'),
  expectedKeywords: z.array(z.string()).default([])
});

router.post('/products', (req, res) => {
  const input = productSchema.parse(req.body);
  if (!db.find('brands', (b) => b.id === input.brandId)) return res.status(400).json({ error: 'Choose an existing brand.' });
  if (db.find('products', (p) => p.gtin === input.gtin)) return res.status(409).json({ error: 'A product with this barcode already exists.' });
  const product = db.insert('products', { id: newId('p'), ...input, referenceImages: [], createdAt: new Date().toISOString() });
  audit(req, 'product.create', product.name);
  res.status(201).json(product);
});

router.put('/products/:id', (req, res) => {
  const input = productSchema.partial().parse(req.body);
  const product = db.update('products', req.params.id, input);
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  audit(req, 'product.update', product.name);
  res.json(product);
});

router.post('/products/:id/images', referenceUpload.array('images', 4), (req, res) => {
  const product = db.find('products', (p) => p.id === req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  product.referenceImages.push(...(req.files || []).map((f) => f.filename));
  db.save();
  audit(req, 'product.images', product.name);
  res.json(product);
});

router.post('/batches', (req, res) => {
  const input = z.object({
    productId: z.string(), batchCode: z.string().trim().toUpperCase().min(3).max(32),
    manufacturedOn: z.string(), expiresOn: z.string(), status: z.enum(['active', 'expired', 'recalled']).default('active'), recallReason: z.string().optional()
  }).parse(req.body);
  if (!db.find('products', (p) => p.id === input.productId)) return res.status(400).json({ error: 'Choose an existing product.' });
  if (db.find('batches', (b) => b.batchCode === input.batchCode)) return res.status(409).json({ error: 'This batch code already exists.' });
  const batch = db.insert('batches', { id: newId('bt'), ...input });
  audit(req, 'batch.create', batch.batchCode);
  res.status(201).json(batch);
});

router.patch('/batches/:id', (req, res) => {
  const input = z.object({ status: z.enum(['active', 'expired', 'recalled']), recallReason: z.string().optional() }).parse(req.body);
  const batch = db.update('batches', req.params.id, input);
  if (!batch) return res.status(404).json({ error: 'Batch not found.' });
  audit(req, `batch.${input.status}`, batch.batchCode);
  res.json(batch);
});

router.post('/identifiers', (req, res) => {
  const input = z.object({ batchId: z.string(), token: z.string().trim().toUpperCase().regex(TOKEN_RE, 'Use the format TM-XX-0000-XXXX.'), singleUse: z.boolean().default(false) }).parse(req.body);
  if (!db.find('batches', (b) => b.id === input.batchId)) return res.status(400).json({ error: 'Choose an existing batch.' });
  if (db.find('identifiers', (i) => i.token === input.token)) return res.status(409).json({ error: 'This code is already registered.' });
  const identifier = db.insert('identifiers', { id: newId('i'), ...input, status: 'active' });
  audit(req, 'identifier.create', identifier.token);
  res.status(201).json(identifier);
});

router.patch('/identifiers/:id', (req, res) => {
  const input = z.object({ status: z.enum(['active', 'revoked']), revokedReason: z.string().optional() }).parse(req.body);
  const patch = input.status === 'revoked' ? { ...input, revokedAt: new Date().toISOString() } : { ...input, revokedAt: null, revokedReason: null };
  const identifier = db.update('identifiers', req.params.id, patch);
  if (!identifier) return res.status(404).json({ error: 'Code not found.' });
  audit(req, `identifier.${input.status}`, identifier.token);
  res.json(identifier);
});

// ---------- Reports -------------------------------------------------------
router.get('/reports', (_req, res) => res.json({ reports: [...db.all('reports')].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) }));

router.patch('/reports/:id', (req, res) => {
  const input = z.object({
    status: z.enum(['new', 'under_review', 'confirmed', 'dismissed']).optional(),
    priority: z.enum(['low', 'medium', 'high']).optional(),
    note: z.string().trim().max(500).optional()
  }).parse(req.body);
  const report = db.find('reports', (r) => r.id === req.params.id);
  if (!report) return res.status(404).json({ error: 'Report not found.' });
  const { note, ...patch } = input;
  if (note) report.notes.push({ at: new Date().toISOString(), by: req.user.name, text: note });
  db.update('reports', report.id, patch);
  audit(req, 'report.update', report.id);
  res.json(report);
});

// ---------- Alerts --------------------------------------------------------
router.get('/alerts', (_req, res) => res.json({ alerts: [...db.all('alerts')].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) }));

router.patch('/alerts/:id', (req, res) => {
  const { status } = z.object({ status: z.enum(['open', 'acknowledged', 'resolved']) }).parse(req.body);
  const alert = db.update('alerts', req.params.id, { status });
  if (!alert) return res.status(404).json({ error: 'Alert not found.' });
  audit(req, `alert.${status}`, alert.id);
  res.json(alert);
});

// ---------- Dashboard -----------------------------------------------------
router.get('/stats', (_req, res) => {
  const scans = db.all('scans');
  const byVerdict = Object.values(BANDS).map((band) => ({ band, count: scans.filter((s) => s.verdict === band).length }));
  const days = [...Array(7)].map((_, i) => { const d = new Date(Date.now() - (6 - i) * 86400000); return d.toISOString().slice(0, 10); });
  const perDay = days.map((day) => ({ day: day.slice(5), scans: scans.filter((s) => s.at.slice(0, 10) === day).length, flagged: scans.filter((s) => s.at.slice(0, 10) === day && s.verdict !== BANDS.GENUINE).length }));
  const tokenCounts = {};
  scans.forEach((s) => { if (s.token) tokenCounts[s.token] = (tokenCounts[s.token] || 0) + 1; });
  const topCodes = Object.entries(tokenCounts).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([token, count]) => ({ token, count }));
  res.json({
    totals: {
      scans: scans.length, openAlerts: db.filter('alerts', (a) => a.status === 'open').length,
      newReports: db.filter('reports', (r) => r.status === 'new').length, products: db.all('products').length
    },
    byVerdict, perDay, topCodes,
    recentScans: [...scans].sort((a, b) => new Date(b.at) - new Date(a.at)).slice(0, 8),
    audit: [...db.all('auditLog')].reverse().slice(0, 8)
  });
});

export default router;
